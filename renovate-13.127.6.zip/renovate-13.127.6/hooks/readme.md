# Docker Hub hooks

This directory is required in order to provide a post-push hook to Docker Hub Autobuild.

See https://docs.docker.com/docker-cloud/builds/advanced/#custom-build-phase-hooks for details.
