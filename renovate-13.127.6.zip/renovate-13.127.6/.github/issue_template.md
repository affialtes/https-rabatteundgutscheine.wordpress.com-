<!--
    Is this about a security problem?
    DO NOT RAISE AN ISSUE - please email security@renovatebot.com instead

    Is this question about config help?
    If so, please open an issue in https://github.com/renovateapp/config-help instead
-->

<!-- Mark an 'x' in the applicable boxes below, e.g. like [x] -->

#### This is a:

- [ ] Bug report (non-security related)
- [ ] Feature request
- [ ] I'm not sure which of those it is

#### I'm using:

- [ ] The Renovate GitHub App
- [ ] Self-hosted GitHub
- [ ] Self-hosted GitLab
- [ ] Self-hosted VSTS

#### Please describe the issue:
