---
name: Security problem
about: Don't raise security issues here. Please email security@renovatebot.com instead.
---

Stop! Don't raise an issue here! Please email security@renovatebot.com instead
