---
name: Configuration help
about: Please create an issue in renovatebot/config-help instead
---

Stop!

Configuration help questions for Renovate are very welcome! However, please raise them in the https://github.com/renovatebot/config-help repository instead.

Maybe you might already find your question answered there by a past issue. If not, please [create a new issue](https://github.com/renovatebot/config-help/issues/new).
