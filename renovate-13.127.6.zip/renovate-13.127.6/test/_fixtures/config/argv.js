module.exports = () => [
  '/usr/local/bin/node',
  '/Users/me/github/renovate/renovate',
];
