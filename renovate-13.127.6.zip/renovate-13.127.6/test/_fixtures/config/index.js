const defaultConfig = require('../../../lib/config/defaults').getConfig();

module.exports = {
  ...defaultConfig,
};
