---
title: JavaScript
description: JavaScript (npm/yarn) Package Manager Support in Renovate
---

# JavaScript

Renovate supports upgrading JavaScript dependencies specified in `package.json` files.
