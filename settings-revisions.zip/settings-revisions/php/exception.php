<?php

class Settings_Revisions_Exception extends Exception {}
