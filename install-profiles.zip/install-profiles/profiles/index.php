<?php
	// http://www.youtube.com/watch?v=bCCORMEYM9o
?>