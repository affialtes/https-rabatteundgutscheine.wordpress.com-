# Outreach

This will include talks, meetups and anything the community is doing to discuss, learn about, and contribute to Gutenberg. This is not an exhaustive list, if we are missing your event just let us know.

## Showcases or demonstrations:
https://wpleeds.co.uk/events/plugins-gutenberg-wordpress-leeds-july-2017/

http://kimb.me/talk-bigwp-london-new-core-wordpress-editor

https://www.facebook.com/events/278785795934302/

https://www.meetup.com/WordPress-Melbourne/events/241543639

https://wpmeetups.de/termin/29-wp-meetup-stuttgart-gutenberg-editor-rueckblick-wordcamp-europe/

## Testing events: 
https://www.meetup.com/Turku-WordPress-Meetup/events/241195076/

https://www.meetup.com/Vancouver-WordPress-Meetup-Group/events/241575161/

## Calls for testing: 
https://make.wordpress.org/test/2017/06/27/call-for-testing-gutenberg/

http://www.wpswfl.org/new-wordpress-editor-gutenberg-early-beta-needs-testers/

https://gutenberg.eastbaywp.com

