# packages

Gutenberg exposes a list of JavaScript packages and tools for WordPress development.

## Using the packages

JavaScript packages are available as a registered script in WordPress and can be accessed using the `wp` global variable.

All the packages are also available on [npm](https://www.npmjs.com/org/wordpress) if you want to bundle them in your code.

<br/><br/><p align="center"><img src="https://s.w.org/style/images/codeispoetry.png?1" alt="Code is Poetry." /></p>