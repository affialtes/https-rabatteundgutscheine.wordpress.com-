# Resources

All resources here can be used by anyone. Feel free to use the decks to make your own talks or to use the gifs in your blog posts and other resources.

## Slidedecks to use

- v1: https://cloudup.com/cqEJppQ8m-5 : August 2017

## Gif collection to use

- https://cloudup.com/c9OKU3OJD9r
