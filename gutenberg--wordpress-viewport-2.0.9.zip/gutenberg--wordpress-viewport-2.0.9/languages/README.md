Languages
=========

The generated POT template file is not included in this repository. To create this file locally, follow instructions from [CONTRIBUTING.md](https://github.com/WordPress/gutenberg/blob/master/CONTRIBUTING.md) to install the project, then run the following command:

```
npm run build
```

After the build completes, you'll find a `gutenberg.pot` strings file in this directory.
