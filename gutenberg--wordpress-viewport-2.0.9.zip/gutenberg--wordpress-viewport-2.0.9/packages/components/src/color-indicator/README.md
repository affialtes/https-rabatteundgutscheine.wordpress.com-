# ColorIndicator

## Usage

```jsx
import { ColorIndicator } from '@wordpress/components';

const MyColorIndicator = () => (
	<ColorIndicator colorValue="#f00" />
);
```
