# Dashicon

## Usage

```jsx
import { Dashicon } from '@wordpress/components';

const MyDashicon = () => (
	<div>
		<Dashicon icon="admin-home" />
		<Dashicon icon="products" />
		<Dashicon icon="wordpress" />
	</div>
);
```
