## 1.1.0 (2018-11-09)

- Add new list of HTML fragments to parse output.
- Optimize JSON-attribute parsing.

## 1.0.2 (2018-11-03)

## 1.0.1 (2018-10-11)

## 1.0.0 (2018-09-30)

-   Initial release.
