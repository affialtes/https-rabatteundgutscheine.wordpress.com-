## 1.1.0 (2018-11-09)

- Add new list of HTML fragments to parse output.
- Optimize JSON-attribute parsing.

## 1.0.4 (2018-11-03)

## 1.0.3 (2018-10-11)

## 1.0.2 (2018-10-01)

## 1.0.1 (2018-08-01)

## 1.0.0 (2018-07-20)

-   Initial release.
