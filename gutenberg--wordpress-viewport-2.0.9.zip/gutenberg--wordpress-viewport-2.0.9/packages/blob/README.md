# Blob

Blob utilities for WordPress.

## Installation

Install the module

```bash
npm install @wordpress/blob --save
```

<br/><br/><p align="center"><img src="https://s.w.org/style/images/codeispoetry.png?1" alt="Code is Poetry." /></p>
