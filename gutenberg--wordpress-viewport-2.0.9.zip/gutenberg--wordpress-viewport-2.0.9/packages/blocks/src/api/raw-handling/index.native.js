export { getPhrasingContentSchema } from './phrasing-content';
