---
name: Question
about: Questions or 'how to' about Gutenberg

---

If you have a question you have a few places that you can ask this:

- Support Forums: https://wordpress.org/support/plugin/gutenberg
- Handbook: https://wordpress.org/gutenberg/handbook
- https://chat.wordpress.org #core-editor

If you are unable to ask in those places you can ask here, however you will get faster responses through those recommended places.
