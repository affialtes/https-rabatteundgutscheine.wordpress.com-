
<html lang="De"><head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="b85b462e6888d82" content="1f161cd5a3afcbfaac2eaa43b85b3f89" />
        <meta name="google-site-verification" content="FvadgHWOiqjkeEcd2zffF6QGthpgUPuRt5OMAPLhTes" />
        <meta name="verification" content="5beb210f277740818ab1e9c19d5e8a6a" />

                <title>Cashback und Rabatt bei SATURN Handytarife</title>
        <meta name="keywords" content="CashbackDeals, Cashback, CashCoins, CashCoin, Rabatt, Webshop, Gutschein, Gutscheincode, Coupon, Schnäppchen, shoppen, sparen, günstig, Aktionscode, Vorteilscode, Vorteil, Geld sparen, Geld verdienen, verdienen, Angebot, Aktion, Geld zurück, Rückvergütung, online shoppen, Cash, Cash back, Promotioncode, Wertbon, Tagesangebot, shoppen mit Rabatt, shoppen mit Cashback, Cashback Seite, Bonus, Verdienst, Vergütung, Ersparnis, Webshop, Online-Shop, shopping" />
        <meta name="description" content="Meben Unterhaltungselektronik und andere Technik in großer Auswahl zu dauerhaften Tiefpreisen kannst du auch einen Handytarif mit Rabatt bei SATURN abschließen." />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta property="og:title" content=""/>
        <meta property="og:description" content=""/>
        <meta property="og:image" content=""/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link rel="alternate" hreflang="De" href="https://www.cashbackdeals.de/cashback/saturn-handytarife-de.php" />

                <meta name="robots" content="noindex">
        
        <link rel="canonical" href="https://www.cashbackdeals.de/cashback/saturn-handytarife-de.php"/>
        <link rel="icon" href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/favicon.ico" type="image/x-icon">
        <link href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/css/layout.css" rel="stylesheet" type="text/css" />
        <link href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/css/popup/popup.css" rel="stylesheet" type="text/css" />
        <link href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/css/help.css" rel="stylesheet" type="text/css" />


        <link href="/general.assets/js/jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css" />

        <link href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/css/popup.style.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="/general.assets/css/sexy-captcha/styles.css" />
        <link href="/general.assets/libs/SpryAssets/SpryCollapsiblePanel.css" type="text/css" rel="stylesheet" />


                <link href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/css/popup/css" type="text/css" rel="stylesheet" media="screen" />
        <link rel="stylesheet" href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/css/jquery.fancybox-visit.css" type="text/css" media="screen" />
        

        <link rel="stylesheet" type="text/css" href="/general.assets/libs/SpryAssets/SpryValidationTextField.css"/>
        <link rel="stylesheet" type="text/css" href="/general.assets/libs/SpryAssets/SpryValidationTextarea.css"/>
        <link rel="stylesheet" type="text/css" href="/general.assets/libs/SpryAssets/SpryValidationCheckbox.css"/>
        <link rel="stylesheet" type="text/css" href="/general.assets/libs/SpryAssets/validation.css"/>
        <link rel="stylesheet" type="text/css" href="/general.assets/libs/SpryAssets/SpryValidationPassword.css"/>
        <link rel="stylesheet" type="text/css" href="/general.assets/css/jquery.counter-analog.css"/>
        <link rel="stylesheet" type="text/css" href="/general.assets/css/date_picker/flora.datepick.css" />
        <link href="/general.assets/css/reviews.css" rel="stylesheet" />
        
                    <link rel="stylesheet" type="text/css" href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/css/hide-seek-game.css"/>
        <link rel="stylesheet" type="text/css" href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/css/hide-seek-animation.css"/>
    
        
                <!--Home trending box tabs -->
        <link rel="stylesheet" type="text/css" href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/css/home-trend-tab.css" />

        <script type="text/javascript" src="/general.assets/js/jquery.min.js"></script>
        <script type="text/javascript" src="/general.assets/js/modernizr.custom.js"></script>
        <script src="/general.assets/js/jquery-ui/jquery-ui.min.js"></script>
        <script type="text/javascript" src="/general.assets/js/jquery.sexy-captcha-0.1.js"></script>
        <script type="text/javascript" src="/general.assets/js/jquery.barrating.min.js"></script>
        <script src="/general.assets/libs/SpryAssets/SpryCollapsiblePanel.js" type="text/javascript"></script>
        <script type="text/javascript" src="/general.assets/libs/fancybox/jquery.fancybox.pack.js"></script>
        <script src="/general.assets/libs/SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
        <script src="/general.assets/libs/SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
        <script src="/general.assets/libs/SpryAssets/SpryValidationCheckbox.js" type="text/javascript"></script>
        <script src="/general.assets/libs/SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
        <script src="/general.assets/js/jquery.counter.js" type="text/javascript"></script>
        <script src="/general.assets/js/jquery.datepick.js" type="text/javascript"></script>
        <script src="/general.assets/js/jquery.datepick-de.js" type="text/javascript"></script>

        <!-- OneSignal -->
        <link rel="manifest" href="/manifest.json">
        <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async></script>

        
        
                <link rel="stylesheet" type="text/css" href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/css/theme-page.css"/>
        <link href="/general.assets/css/jquery.bxslider.cbk.css" rel="stylesheet" />
        <script src="/general.assets/js/bxslider.min.js"></script>
        	
                        
                
        <link href="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/css/responsive.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" />
        <link href='https://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css' />
        <link href='https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700' rel='stylesheet' type='text/css' />   
        
        <link href="/general.assets/css/icon-fonts/font.css" rel="stylesheet" type="text/css" />
        
                <link href="https://plus.google.com/106394136536174905587" rel="publisher">
        
        
        <script>


            var gaProperty = 'UA-45187893-1';
            var disableStr = 'ga-disable-' + gaProperty;
            if (document.cookie.indexOf(disableStr + '=true') > - 1) {
            window[disableStr] = true;
            }
            function gaOptout() {
            document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
            window[disableStr] = true;
            }

            (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                    m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
            })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
            ga('create', 'UA-45187893-1', 'auto');
            ga('set', 'anonymizeIp', true);
            ga('send', 'pageview');
            $(document).ready(function () {
            $("#menu_icon").click(function () {
            $(".burger_menu").toggle();
            });
            $(".cat-menu").click(function () {
            $(".CatLinkCont").toggle();
            });
            /* Header Messager Timer */
            if ($('#timer').length > 0) {
            var timer;
            var compareDate = new Date('');
            compareDate.setDate(compareDate.getDate() + parseInt(''));
            compareDate.setHours(23);
            compareDate.setMinutes(59);
            compareDate.setSeconds(59);
            timer = setInterval(function () {
            timeBetweenDates(compareDate);
            }, 1000);
            function timeBetweenDates(toDate) {
            var dateEntered = toDate;
            var now = new Date();
            var difference = dateEntered.getTime() - now.getTime();
            if (difference <= 0) {
            // Timer done
            clearInterval(timer);
            $('#timer').css('visibility', 'hidden');
            } else {
            var seconds = Math.floor(difference / 1000);
            var minutes = Math.floor(seconds / 60);
            var hours = Math.floor(minutes / 60);
            var days = Math.floor(hours / 24);
            hours %= 24;
            minutes %= 60;
            seconds %= 60;
            $("#days").text(days);
            $("#hours").text(hours);
            $("#minutes").text(minutes);
            $("#seconds").text(seconds);
            }
            }
            }
            });
        </script>
        
                
        <script type="text/javascript">
            $(document).ready(function () {
            $("h2.cat-icon").click(function () {
            $(".categoryContainerHeader").toggle();
            });
            $("h2.account-icon").click(function () {
            $(".todoContainerHeader").hide();
            $(".myAcoountContainerHeader").toggle();
            });
            $("h2.todo-icon").click(function () {
            $(".myAcoountContainerHeader").hide();
            $(".todoContainerHeader").toggle();
            });
            });
        </script>
        

                </head>
        <div id="fb-root"></div>
    <script src="/general.assets/js/fb_login.js" type="text/javascript"></script> 
        <body>
                        <section class="bodyWrapper" onclick="closeCookieBar();">

            <!-- ADMIN BAR start -->
            

            
            <!-- ADMIN BAR end -->
            <!-- Takeover Different banner code start -->
                        <!-- takeover diff banner code end -->
                        <div class="leftBanner main_banner">
                
                                                                                                                                                                <a class="various" href="#inline_store_visit" onClick="loginFancyPopUP({cashback: '20,00 ', storeName: 'EnBW', urlKey: 'enbw', imgUrl: 'https://static.orangebuddies.nl/image/stores/96520.jpg', itemId: '0', bannerId: '35522', isCbkDay: '1'})" title="EnBW"><img class="main_sidebanner" width="120" height="400" src="https://static.orangebuddies.nl/image/banners/35522-SkyScraperWrapper.jpg" alt="EnBW" /></a>
                                                <img src="" width="0" height="0" style="display:none"/>
                                            </div>
                        <!-- new -->
            <div id="top-container" class="clearfix">
                <div id="top"> 
                    <span class="top-usp">

                                                                                            </span>
                                        <div id="top-subscribe">
                        <span><a href="javascript:void(0);" class="t-user active"><i class="fa fa-globe" aria-hidden="true"></i>  </i></a>
                            <div>
                                <div class="column">

                                    <ul>
                                        <li><a target="_blank" href="https://www.cashbackkorting.nl/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/netherlands.jpg" alt="netherlands-flag" title ="netherlands-flag"></span> <span> Cashbackkorting.nl<!--Niederlande--></span> </a> </li>
                                        <li> <a target="_blank" href="http://www.cashbackdeals.be/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/belgium.jpg" alt="belgium-flag" title ="belgium-flag"></span> <span> Cashbackdeals.be<!--Belgien--></span> </a> </li>
                                        <li><a target="_blank" href="https://www.cashbackreduction.fr/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/france.jpg" alt="france-flag" title ="france-flag"></span> <span> Cashbackreduction.fr<!--Frankreich--></span> </a> </li>
                                        <li><a target="_blank" href="https://www.cashbackdeals.de/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/germany.jpg" alt="germany-flag" title ="germany-flag"></span> <span> Cashbackdeals.de<!--Deutschland--></span> </a> </li>
                                        <li><a target="_blank" href="https://www.cashbacksparen.at/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/austria.jpg" alt="austria-flag" title ="austria-flag"></span> <span> Cashbacksparen.at<!--Österreich--></span> </a> </li>
                                        <li><a target="_blank" href="https://www.cashbackdeals.ch/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/switzerland.jpg" alt="switzerland-flag" title ="switzerland-flag"></span> <span> Cashbackdeals.ch<!--Schweiz--></span> </a> </li>
                                        <li><a target="_blank" href="https://www.cashbackrabat.pl/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/poland.jpg" alt="poland-flag" title ="poland-flag"></span> <span> Cashbackrabat.pl<!--Polen--></span> </a> </li>

                                        <li><a target="_blank" href="https://www.cashbackdeals.it/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/italy.jpg" alt="italy-flag" title ="italy-flag"></span> <span> Cashbackdeals.it<!--Italien--></span> </a> </li>
                                        <li><a target="_blank" href="https://www.cashbackearners.co.uk/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/uk.jpg" alt="uk-flag" title ="uk-flag"></span> <span> Cashbackearners.co.uk<!--England--></span> </a> </li>
                                        <li><a target="_blank" href="https://www.cashbackdeals.se/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/sweden.jpg" alt="sweden-flag" title ="sweden-flag"></span> <span> Cashbackdeals.se<!--Schweden--></span> </a> </li>
                                        <li> <a target="_blank" href="http://www.cashbackdeals.es/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/spain.png" alt="spain-flag" title ="spain-flag"></span> <span> Cashbackdeals.es<!--Spanien--></span> </a> </li>
                                        <li><a target="_blank" href="https://www.cashbackdeals.fi/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/finland.png" alt="finland-flag" title ="finland-flag" /></span><span> Cashbackdeals.fi<!--Finnland--></span></a> </li>
                                        <li><a target="_blank" href="https://www.cashbackearners.com/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/usa.png" alt="usa-flag" title ="usa-flag" /></span><span> Cashbackearners.com<!--Finnland--></span></a> </li>

                                        <li><a target="_blank" href="https://www.cashbackearners.com.au/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/australia.png" alt="australia-flag" title ="australia-flag" /></span><span> Cashbackearners.com.au</span></a> </li>
                                        <li><a target="_blank" href="https://www.cashbackearners.ca/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/Canada.png" alt="canada-flag" title ="canada-flag"></span> <span> Cashbackearners.ca </span> </a> </li>
                                        <li><a target="_blank" href="https://www.cashbackdeals.dk/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/denmark.png" alt="denmark-flag" title ="denmark-flag" /></span><span> Cashbackdeals.dk</span></a> </li>
                                        <li><a target="_blank" href="https://www.cashbackdeals.cz/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/czech.png" alt="czech-flag" title ="czech-flag" /></span><span> Cashbackdeals.cz</span></a> </li>
                                        <li><a target="_blank" href="https://www.cashbackdeals.no/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/norway.jpg" alt="norway-flag" title ="norway-flag" /></span><span> Cashbackdeals.no</span></a> </li>
                                        <li><a target="_blank" href="https://www.cashbackdeals.pt/"><span><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/portugal.png" alt="portugal-flag" title ="portugal-flag" /></span><span> Cashbackdeals.pt</span></a> </li>

                                    </ul>
                                </div>
                            </div>
                        </span>
                                                <span class="w-user">
                            <a href="/" class="t-user active"><i class="fa fa-user"></i> Willkommen Jasmin</a>
                            <div>
                                <div class="column">
                                    <ul>
                                        <li><a href="/user/cashback.php"><i class="fa fa-database"></i> Saldo 21,690</a></li>
                                        <li><a href="/user/welcome.php"><i class="fa fa-pencil"></i> Mein Konto</a></li>
                                        <li><a href="/user/cashmail.php"><i class="fa fa-envelope"></i> Posteingang (73)</a></li>
                                        <li><a href="/user/logout.php"><i class="fa fa-power-off"></i> Ausloggen</a></li>
                                    </ul>
                                </div>
                            </div>
                        </span>

                        
                                                
                        <span class="notifi-dd">
                            <sapn class="notifi-icon">
                                <a href="javascript:void(0)"><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/notify_bell.png"></a>
                                <span class="notifi-no">0</span>
                            </sapn>	
                            <div class="notifi-list">
                                <ul>                                     <li class="no-notifi">
                                        Keine neue Benachrichtigungen
                                    </li>  
                                                                        <li class="notifi-all">
                                        <span><a href="/user/notifications.php">Alle Benachrichtigungen anzeigen</a></span>	 
                                    </li>
                                </ul>
                            </div>	
                        </span>

                                                

                        <span class="top-help">
                            <a href="/static/help" class="t-help t-user active"><i class="fa fa-info-circle"></i> Hilfe</a>
                            <div>
                                <div class="column">
                                    <ul>
                                        <li><a href="/static/faq.php"><i class="fa fa-question-circle">
                                                </i>FAQ</a></li>
                                        <li><a href="/static/contact.php"><i class="fa fa-comment-o"></i> Anfrage stellen </a></li>
                                        <li><a href="/user/generateticket.php"><i class="fa fa-cart-plus"></i> Antrag für fehlende Transaktion stellen </a></li>
                                        <li><a href="/user/ticket.php"><i class="fa fa-ticket"> </i>Deine Hilfe-Tickets  </a></li>
                                    </ul>
                                </div>
                            </div>
                        </span>
                    </div>
                </div>
            </div>
            <!-- end new -->
            <!-- Header -->
            <div id="header"> 
                <a href="/" title="CashbackDeals.de">
                    <img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/logo.png" alt="CashbackDeals.de" id="logo" />
                </a>
                <div id="search">
                    <input type="hidden" name="lbl_find_shop_action" id="lbl_find_shop_action" value="Suche Shop, Produkt oder Deal" />
                    <form method="get" action="/search/search.php" id="frmMainSearch">
                        <input type="text" autocomplete="off" class="search-field" value="Suche Shop, Produkt oder Deal" name="q"  id="searchinput" onKeyUp="getSearchResults(this.value, 'searchBox', 'search_results.php', '', 'searchChkbox')" />
                                 
                        <div class="searc-selection">
                            <button type="button" class="searc-SDD" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-caret-down"></i></button>
                            <div class="searc-SDC" style="">
                                <span class="searc-sel-opt"><label><input  class="searchChkbox" type="checkbox" name="store" value="store" checked onchange= "getSearchResults($('#searchinput').val(), 'searchBox', 'search_results.php', '', 'searchChkbox')" > Shops</label></span>
                                <span class="searc-sel-opt"><label><input  class="searchChkbox" type="checkbox"  name="deal" value="deal" checked onchange= "getSearchResults($('#searchinput').val(), 'searchBox', 'search_results.php', '', 'searchChkbox')" >  Angebote</label></span>
                                <span class="searc-sel-opt"><label><input  class="searchChkbox" type="checkbox" name="category" value="category" checked onchange= "getSearchResults($('#searchinput').val(), 'searchBox', 'search_results.php', '', 'searchChkbox')" >  Kategorien</label></span>
                                <span class="searc-sel-opt"><label><input  class="searchChkbox" type="checkbox" name="faq" value="faq" checked onchange= "getSearchResults($('#searchinput').val(), 'searchBox', 'search_results.php', '', 'searchChkbox')" >  FAQ</label></span>
                            </div>	
                        </div>
                                                <input type="submit" value='' class="search-submit" id="searchbtn" />
                        <div style="background: none repeat scroll 0 0 #FFFFFF;display:none;margin-top:29px;position:absolute;width:250px;z-index:222;" id="searchBox"></div>
                    </form>
                                        <div id="search-tips">
                        Tipps:                         <a href="/cashback/vodafone-mobilfunk.php">Vodafone (Mobilfunk & Data)</a>
                                                <a href="/cashback/deutsche-postbank.php">Postbank</a>
                                                <a href="/cashback/bonprixde.php">bonprix</a>
                                                <a href="/cashback/blau-mobilfunk-de.php">blau Mobilfunk</a>
                                            </div>
                                    </div>

                
                <script type="application/ld+json">
                    {
                    "@context": "http://schema.org",
                    "@type": "WebSite",
                    "url": "https://www.cashbackdeals.de/",
                    "potentialAction": {
                    "@type": "SearchAction",
                    "target": "https://www.cashbackdeals.de/search/search.php?q={search_term}",
                    "query-input": "required name=search_term"
                    }
                    }
                </script>
                 </div>
            <div id="container" class="clearfix">
                <div id="menu">
                    <h1 class="heading-1" style="display: none;"><a href="https://www.cashbackdeals.de/">Verdiene Geld mit :</a></h1>
                    <ul>                
                        <li><a  href="/shops/shops.php?url_key=all">Shoppen</a>
                            <div>
                                <div class="nav-column">
                                    <h3>
                                        <a href="/shops/all-categories.php">Kategorien</a>
                                    </h3>
                                                                        <ul>
                                                                                <li><a href="/shops/category-overview.php?url_key=baby-und-kind">Baby & Kind</a></li>
                                                                                <li><a href="/shops/category-overview.php?url_key=bucher-und-zeitschriften">Bücher & Zeitschriften</a></li>
                                                                                <li><a href="/shops/category-overview.php?url_key=geschenke-und-gadgets">Geschenke & Gadgets</a></li>
                                                                                <li><a href="/shops/category-overview.php?url_key=computer">Elektronik & Unterhaltung</a></li>
                                                                                <li><a href="/shops/category-overview.php?url_key=foto-und-kamera">Foto & Kamera</a></li>
                                                                                <li><a href="/shops/category-overview.php?url_key=mode">Mode & Fashion</a></li>
                                                                                <li><a href="/shops/category-overview.php?url_key=finanzen">Finanzen & Strom</a></li>
                                                                                <li><a href="/shops/category-overview.php?url_key=haushalt">Haushalt</a></li>
                                                                                <li><a href="/shops/category-overview.php?url_key=games-filme-und-musik">Games, Filme & Musik</a></li>
                                                                                <li><a href="/shops/all-categories.php" class="nav-all">Alle Kategorien</a></li>
                                    </ul>
                                                                    </div>
                                <div class="nav-column">
                                    <h3>
                                        <a href="/shops/shops.php?url_key=all">Shoppen</a>
                                    </h3>
                                                                        <ul>
                                                                                <li>
                                            <a href="/cashback/na-kd-com.php">NA-KD.com</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/vodafone-dsl.php">Vodafone (DSL, LTE & TV)</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/blau-mobilfunk-de.php">blau Mobilfunk</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/nord-vpn-de.php">NordVPN</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/agila.php">AGILA</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/groupon-shopping.php">Groupon Shopping</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/o2-de.php">O2</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/tarifcheck24.php">TARIFCHECK</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/saturn.php">SATURN</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/vodafone-mobilfunk.php">Vodafone (Mobilfunk & Data)</a>
                                        </li>
                                                                                <li>
                                            <a href="/shops/shops.php?url_key=all" class="nav-all">Alle Online-Shops</a>
                                        </li>
                                    </ul>
                                                                    </div>
                                <div class="nav-column">
                                    <h3><a href="/shops/newshops.php">Neue Shops</a></h3>
                                    <ul>
                                                                                                                        <li>
                                            <a href="/cashback/supershop.php">SUPERSHOP</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/oxfamunverpackt.php">OxfamUnverpackt</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/holi-concept.php">Holi Concept</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/germania-de.php">Germania</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/kosmetikfuchsde.php">kosmetikfuchs.de</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/pati-versand-de.php">Pati-Versand.de</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/ego-ist.php">EGO_IST</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/hitseller-de.php">hitseller.de</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/masters-de.php">Master's</a>
                                        </li>
                                                                                <li>
                                            <a href="/cashback/multilotto-de.php">Multilotto</a>
                                        </li>
                                                                                <li><a class="nav-all" href="/shops/newshops.php">Alle neuen Shops ansehen </a></li>
                                                                            </ul>
                                </div>
                                <div class="nav-action">
                                                                    </div>
                            </div>
                        </li>

                        <li>
                            <a  href="/shops/deals.php">Angebote</a>
                            <div class="nav-small">
                                <!-- please note this extra classs for small submenus -->
                                <div class="nav-column">
                                    <ul>
                                        <li>
                                            <a href="/shops/dailydeals-service.php">Tagesangebote </a>
                                        </li>
                                        <li>
                                            <a href="/shops/deals.php?type=kortingscodes">Rabattcodes </a>
                                        </li>
                                        <li>
                                            <a href="/shops/deals.php?type=last">Letzte Chance </a>
                                        </li>
                                        <li>
                                            <a href="/shops/deals.php?type=new">Neue Angebote </a>
                                        </li>
                                        <li>
                                            <a href="/shops/deals.php?type=tip">Beliebte Angebote </a>
                                        </li>
                                        <li>
                                            <a href="/shops/deals.php?type=special">Sonderangebote </a>
                                        </li>
                                        <li>
                                            <a href="/static/manufacturer-cashback/">Cashback-Aktionen der Hersteller </a>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li><a href="/comparison/">Vergleich</a></li>
                        <li><a  href="/shops/shops.php">Gratis </a></li>
                        <li><a href="/static/earn-money.php">Sofort Verdienst</a>
                            <div class="nav-small">
                                <!-- please note this extra classs for small submenus -->
                                <div class="nav-column">
                                    <ul>
                                        <li><a href="/user/cashmail.php">CashMails </a></li>
                                        <li><a href="/shops/bannerkliks.php">Bannerklicks </a></li>
                                        <li><a href="/shops/click-earn-campaigns.php">Klicken und Verdienen </a></li>
                                        <li><a href="/shops/delen.php">Teilen </a></li>
                                        <li><a href="/user/inbox-surveys.php">Umfragen </a></li>
                                        <li><a href="/static/whatsapp.php">WhatsApp </a></li>
                                                                            </ul>
                                </div>
                            </div>
                        </li>
                        <li><a  href="/user/cashboost-new.php">Cashboost</a>
                            <div class="nav-small">
                                <!-- please note this extra classs for small submenus -->
                                <div class="nav-column">
                                    <ul>
                                                                                                                        <li>
                                            <a href="/user/detail.php">
                                                Profil ergänzen
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/user/cashboost.php">
                                                Freunde einladen
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/static/mobile-app.php">
                                                App installieren
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/static/toolbar.php">
                                                Cashback-Melder downloaden
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/testimonials/add.php">
                                                Empfehlung schreiben
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/shops/reviews.php">
                                                Online-Shops bewerten
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/static/top-campaigns.php">
                                                Top Deals
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/spellen/">
                                                Spiele
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/onlinepanel/">
                                                Online Panels
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/comparison/">
                                                Vergleich
                                            </a>
                                        </li>
                                                                                                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li><a  href="/shops/win-competition.php">Gewinnen</a>
                            <div class="nav-small">
                                <!-- please note this extra classs for small submenus -->
                                <div class="nav-column">
                                    <ul>
                                                                                                                        <li>
                                            <a href="/user/sports-predictions.php">
                                                Ergebnis voraussagen
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/user/competitions/">
                                                Aktionen/Wettbewerbe
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/user/lottery.php">
                                                Lotterie
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/user/jackpot.php">
                                                Jackpot
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/user/bingo.php">
                                                Bingo
                                            </a>
                                        </li>
                                                                                <li>
                                            <a href="/user/find-the-code.php">
                                                Finde den Code
                                            </a>
                                        </li>
                                        
                                        
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li><a href="/blog/">Blog</a></li>
                        <li class="download-app-menu"><a class="app-icon"  href="/static/mobile-app.php"><div class="download-app"><span>APP</span></div>
                            </a></li>
                        <li class="download-app-menu"><a class="app-icon"  href="/static/toolbar.php"><div class="alert-bar"><span>Alert</span></div>
                            </a></li>
                                            </ul>
                </div>
                <!--- responseiv menu-->
                <div class="burgermenu">
                    <div id="menu_icon"> <img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/burger_menu.png" alt="Menu" title ="Menu" width="20px" height="16px"> Verdiene Geld mit</div>
                    <div class="resp-app-button"> <a class="app-icon" href="/static/mobile-app.php">
                            <div class="download-app"><span>APP</span></div>
                        </a> <a class="app-icon" href="/static/toolbar.php">
                            <div class="alert-bar"><span>Alert</span></div>
                        </a> </div>
                    <div class="burger_menu">
                        <ul class="cd-accordion-menu">
                            <li class="has-children">
                                <input type="checkbox" name="group-1" id="group-1">
                                <label for="group-1">Shoppen</label>
                                <ul>
                                    <li class="has-children">
                                        <input type="checkbox" name="sub-group-1" id="sub-group-1">
                                        <label for="sub-group-1">Kategorien</label>
                                                                                <ul>
                                                                                        <li><a href="/shops/category-overview.php?url_key=baby-und-kind">Baby & Kind</a></li>
                                                                                        <li><a href="/shops/category-overview.php?url_key=bucher-und-zeitschriften">Bücher & Zeitschriften</a></li>
                                                                                        <li><a href="/shops/category-overview.php?url_key=geschenke-und-gadgets">Geschenke & Gadgets</a></li>
                                                                                        <li><a href="/shops/category-overview.php?url_key=computer">Elektronik & Unterhaltung</a></li>
                                                                                        <li><a href="/shops/category-overview.php?url_key=foto-und-kamera">Foto & Kamera</a></li>
                                                                                        <li><a href="/shops/category-overview.php?url_key=mode">Mode & Fashion</a></li>
                                                                                        <li><a href="/shops/category-overview.php?url_key=finanzen">Finanzen & Strom</a></li>
                                                                                        <li><a href="/shops/category-overview.php?url_key=haushalt">Haushalt</a></li>
                                                                                        <li><a href="/shops/category-overview.php?url_key=games-filme-und-musik">Games, Filme & Musik</a></li>
                                                                                    </ul>
                                                                            </li>
                                    <li class="NoSubMenu"><a href="/shops/all-categories.php" target="_self">Alle Kategorien</a></li>
                                    <li class="has-children">
                                        <input type="checkbox" name="sub-group-2" id="sub-group-2">
                                        <label for="sub-group-2">Shoppen</label>
                                        <ul>
                                                                                        <li>
                                                <a href="/cashback/na-kd-com.php">NA-KD.com</a>
                                            </li>
                                                                                        <li>
                                                <a href="/cashback/vodafone-dsl.php">Vodafone (DSL, LTE & TV)</a>
                                            </li>
                                                                                        <li>
                                                <a href="/cashback/blau-mobilfunk-de.php">blau Mobilfunk</a>
                                            </li>
                                                                                        <li>
                                                <a href="/cashback/nord-vpn-de.php">NordVPN</a>
                                            </li>
                                                                                        <li>
                                                <a href="/cashback/agila.php">AGILA</a>
                                            </li>
                                                                                        <li>
                                                <a href="/cashback/groupon-shopping.php">Groupon Shopping</a>
                                            </li>
                                                                                        <li>
                                                <a href="/cashback/o2-de.php">O2</a>
                                            </li>
                                                                                        <li>
                                                <a href="/cashback/tarifcheck24.php">TARIFCHECK</a>
                                            </li>
                                                                                        <li>
                                                <a href="/cashback/saturn.php">SATURN</a>
                                            </li>
                                                                                        <li>
                                                <a href="/cashback/vodafone-mobilfunk.php">Vodafone (Mobilfunk & Data)</a>
                                            </li>
                                                                                    </ul>
                                    </li>
                                    <li><a href="/shops/shops.php?url_key=all" target="_self">Alle shops</a></li>
                                    <li class="has-children">
                                        <input type="checkbox" name="sub-group-3" id="sub-group-3">
                                        <label for="sub-group-3">Hervorgehoben</label>
                                        <ul>
                                            
                                            <li><a href="/shops/deals.php">Angebote</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li class="has-children">
                                <input type="checkbox" name="sub-group-4" id="sub-group-4">
                                <label for="sub-group-4">Angebote</label>
                                <ul>
                                    <li>
                                        <a href="/shops/dailydeals-service.php">Tagesangebote </a>
                                    </li>
                                    <li>
                                        <a href="/shops/deals.php?type=kortingscodes">Rabattcodes </a>
                                    </li>
                                    <li>
                                        <a href="/shops/deals.php?type=new">Neue Angebote </a>
                                    </li>
                                    <li>
                                        <a href="/shops/deals.php?type=tip">Beliebte Angebote </a>
                                    </li>
                                    <li>
                                        <a href="/shops/deals.php?type=special">Sonderangebote </a>
                                    </li>
                                    <li>
                                        <a href="/static/manufacturer-cashback/">Cashback-Aktionen der Hersteller </a>
                                    </li>

                                </ul>
                            </li>
                            <li><a href="/comparison/" target="_self">Vergleich</a></li>
                            <li><a href="/shops/shops.php" target="_self">Gratis</a></li>
                            <li class="has-children">
                                <input type="checkbox" name="sub-group-5" id="sub-group-5">
                                <label for="sub-group-5">Sofort Verdienst</label>
                                <ul>
                                    <li><a href="/user/cashmail.php">CashMails </a></li>
                                    <li><a href="/shops/bannerkliks.php">Bannerklicks </a></li>
                                    <li><a href="/shops/click-earn-campaigns.php">Klicken und Verdienen </a></li>
                                    <li><a href="/shops/delen.php">Teilen </a></li>
                                    <li><a href="/static/whatsapp.php">WhatsApp </a></li>
                                                                    </ul>
                            </li>
                            <li class="has-children">
                                <input type="checkbox" name="sub-group-6" id="sub-group-6">
                                <label for="sub-group-6">Cashboost</label>
                                <ul>
                                                                                                            <li>
                                        <a href="/user/detail.php">
                                            Profil ergänzen
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/user/cashboost.php">
                                            Freunde einladen
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/static/mobile-app.php">
                                            App installieren
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/static/toolbar.php">
                                            Cashback-Melder downloaden
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/testimonials/add.php">
                                            Empfehlung schreiben
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/shops/reviews.php">
                                            Online-Shops bewerten
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/static/top-campaigns.php">
                                            Top Deals
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/spellen/">
                                            Spiele
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/onlinepanel/">
                                            Online Panels
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/comparison/">
                                            Vergleich
                                        </a>
                                    </li>
                                                                                                  
                                </ul>
                            </li>
                            <li class="has-children">
                                <input type="checkbox" name="sub-group-7" id="sub-group-7">
                                <label for="sub-group-7">Gewinnen</label>
                                <ul>
                                                                                                            <li>
                                        <a href="/user/sports-predictions.php">
                                            Ergebnis voraussagen
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/user/competitions/">
                                            Aktionen/Wettbewerbe
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/user/lottery.php">
                                            Lotterie
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/user/jackpot.php">
                                            Jackpot
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/user/bingo.php">
                                            Bingo
                                        </a>
                                    </li>
                                                                        <li>
                                        <a href="/user/find-the-code.php">
                                            Finde den Code
                                        </a>
                                    </li>
                                                                                                        </ul>
                            </li>
                            <li> <a href="/blog/" target="_self">Blog</a> </li>
                                                        
                        </ul>
                    </div>
                </div>
                <!-- end of responsive -->
                <div id="main">
                    <div id="main-content">
                                                <div class="alert-popup-wrap">
                            <div class="alert-popup-content" id="">
                                <div class="alert-popup-exit"></div>
                                                            </div>
                        </div>

                          
        <!--
<style type="text/css">
                .store-reviews{
                    width: 100%;
                    overflow: hidden;
                }
                .store-reviews .br-theme-bars-movie .br-widget a{
                    width: 90px;
                }
                h2 .shop-main-rating{
                    font-size:14px;
                    margin-left: 10px;
                } 
                .shop-main-rating-link{
                    float: left;
                }
                .shop-main-sidebar-header{
                    border:none;
                }
</style> -->
<script type="text/javascript" src="/general.assets/js/moment/moment-with-locales.min.js"></script>
<script type="text/javascript" src="/general.assets/js/moment/moment-timezone-with-data-2010-2020.min.js"></script>
<script type="text/javascript">
           $(function() {

              $('#rating').barrating({
                theme: 'fontawesome-stars',
                showSelectedRating: 'true',
                initialRating:  5 ,
                allowEmpty: 'null',
                readonly: true
              });
              
              $('#priceRating').barrating({
                theme: 'bars-movie',
                showSelectedRating: 'true',
                initialRating: 5 ,
                allowEmpty: 'null',
                readonly: true
              });
              $('#shippingRating').barrating({
                theme: 'bars-movie',
                showSelectedRating: 'true',
                initialRating: 5 ,
                allowEmpty: 'null',
                readonly: true
              });
              $('#serviceRating').barrating({
                theme: 'bars-movie',
                showSelectedRating: 'true',
                initialRating: 5 ,
                allowEmpty: 'null',
                readonly: true
              });
              $('#cashbackRating').barrating({
                theme: 'bars-movie',
                showSelectedRating: 'true',
                initialRating: 5 ,
                allowEmpty: 'null',
                readonly: true
              });

           });
        
    function showbox(id) {
        $('#' + id).slideToggle(500);
    }
    $(document).ready(function () {

        //$('.discountSslider').bxSlider();
        /*storeSlider('.discountSslider', '', 1, 4, 8);*/
        if($('.userViewStoreSlider li').length > 0)
        storeSlider('.userViewStoreSlider', '', 1, 3, $('.userViewStoreSlider li').length);
        if($('.blogslider li').length > 0)
        storeSlider('.blogslider', '', 1, 3, $('.blogslider li').length);

        $('.bx-loading').css("display", "none");

        if($('.timer-store-deal').length > 0){
            var zone = 'Europe/Berlin';
            var momentObj = moment;
            function getTimeRemaining(endtime) {

                /* Time Zone Conversion*/
                var currentDateTime = momentObj.tz(new Date(), zone).format();
                var passDateTime = momentObj.tz(endtime, zone).format();

                var t = Date.parse(passDateTime) - Date.parse(currentDateTime);
                var seconds = Math.floor((t / 1000) % 60);
                var minutes = Math.floor((t / 1000 / 60) % 60);
                var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
                return {
                    'total': t,
                    'hours': hours,
                    'minutes': minutes,
                    'seconds': seconds
                };
            }

            function initializeClock(id, endtime) {
                var clock = document.getElementById(id);
                var hoursSpan = clock.querySelector('.shours');
                var minutesSpan = clock.querySelector('.sminutes');
                var secondsSpan = clock.querySelector('.sseconds');

                function updateClock() {
                    var t = getTimeRemaining(endtime);

                    hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
                    minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
                    secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

                    if (t.total <= 0) {
                        clearInterval(timeinterval);
                    }
                }

                updateClock();
                var timeinterval = setInterval(updateClock, 1000);
            }

            //var deadline = new Date(Date.parse(new Date()) + 1 * 24 * 60 * 60 * 1000);
            $('.timer-store-deal').each(function(i, k){
                var deadline = $(k).data('time');
                var hasTimer = $(k).data('timer');
                var dealID = $(k).data('did');
                if(hasTimer){
                    initializeClock(dealID, deadline);
                }

            });
        }
    });
</script>
    



<div id="main-content">
    <div id="breadcrumbs"><ol itemscope itemtype="http://schema.org/BreadcrumbList"> 
                  <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                      <a itemprop="item" href="https://www.cashbackdeals.de/">
                      <span itemprop="name">Startseite</span></a>
                      <meta itemprop="position" content="1" />
                  </li><li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                        <a itemprop="item" href="https://www.cashbackdeals.de/shops/shops.php?url_key=all">
                        <span itemprop="name">Shoppen</span></a> 
                        <meta itemprop="position" content="2" />
                    </li><li>SATURN Handytarife</li></ol></div>
           <div class="ShopDetailTab" id="FixTab">
        <a href="#Cashback">CashCoins</a>
                  <a href="#Kortingscodes">Gutscheincodes & Aktionen</a>
                                          <a href="#reviews">Bewertungen</a>
            </div>
  
    <div id="MyTab1" class="ShpDeTabcontent" style="display: block;">
        <div class="shop-main-detail">
                                                                        
                                                            <!-- google plus share desc -->
            <span itemprop="name" style="display:none;">Bekomme genau wie ich (bis zu) 37,50  CashCoins bei SATURN Handytarife.</span>
            <!-- google plus share desc end -->
            <div class="shop-main-intro clearfix">
                
                 <a name="Cashback" id="Cashback"></a>
                <h2 class="new-heading">Cashback und Rabatt bei SATURN Handytarife</h2>
                                                            </div>

            <div class="shop-main-info">
                <!-- hide and seek game step 1 start -->
                                <!-- hide and seek game step 1 end -->
                <div class="shop-main-sidebar-header clearfix">
                    <span class="shop-main-img"><img itemprop="image" src="https://static.orangebuddies.nl/image/stores/61894.jpg" width="120" alt="SATURN Handytarife"/></span>
                    <span class="shop-main-rating">
                        <a href="/review/saturn-handytarife-de.php">
                            <img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/star/new/rating_10.png"
                                 alt="Shopbewertung : 10"/>
                                                        (1 Bewertungen)
                                                    </a>
                    </span>
                                        <div id="shop-main-button"><a class="xlargebutton various" href="#inline_store_visit"
                                                  onclick="loginFancyPopUP({cashback: '37,50 ', storeName: 'SATURN Handytarife', urlKey: 'saturn-handytarife-de', isCbkDay: '1', imgUrl: 'https://static.orangebuddies.nl/image/stores/61894.jpg'})"><span>Bestelle mit CashCoins>></span></a>
                    </div>
                                    </div>
                <!-- hide and seek game step2 start -->
                                <!-- hide and seek game step2 end -->
                <div class="shop-main-info-text">
                    <h2>Handytarif mit Rabatt abschließen bei SATURN und sparen!</h2>
SATURN bietet dir nicht nur Unterhaltungselektronik und andere Technik in großer Auswahl zu dauerhaften Tiefpreisen. Bei SATURN kannst du jetzt auch deinen neuen oder nächsten Handytarif abschließen und erhältst Rabatt. Heute noch deinen Handytarif abschließen und sparen.
                </div>
                <!-- Deals Section starts -->
                                <div class="shop-main-cashback">
                    <div class="shop-main-cashback-title clearfix">
                        <div class="shop-main-cashback-head">Kategorien</span></div>
                        <div class="shop-cb">CashCoins <i class="fa fa-caret-down"></i></span></div>
                    </div>
                    <div class="exDeals">
                        <!-- Foreach of Deals -->
                        
                                                                                                <!-- Master Formula calculate Increased Commission -->
                        
                                                <!-- Percent Block -->
                                                                                                                        <!-- Percent Block Ends-->
                                                
                                                <!-- New Section Started -->
                        <div class="exDealsRow">
                            <div class="DealsLeft"><a href="#">Alle Tarife mit einer Grundgebühr ab 30 €/mtl.</a></div>
                            <div class="DealsMid">
                                
                                                                                            </div>
                            <div class="DealsRight">
                                                                <!-- Exclusive | Show old Commission & Commission -->
                                                                                                37,50
                                
                                                                                            </div>
                            <!-- Details -->
                                                    </div>
                        
                                                                                                <!-- Master Formula calculate Increased Commission -->
                        
                                                <!-- Percent Block -->
                                                                                                                        <!-- Percent Block Ends-->
                                                
                                                <!-- New Section Started -->
                        <div class="exDealsRow">
                            <div class="DealsLeft"><a href="#">Alle Tarife mit einer Grundgebühr von 15,00 €/mtl. bis einschließlich 29,99 €/mtl</a></div>
                            <div class="DealsMid">
                                
                                                                                            </div>
                            <div class="DealsRight">
                                                                <!-- Exclusive | Show old Commission & Commission -->
                                                                                                25,00
                                
                                                                                            </div>
                            <!-- Details -->
                                                    </div>
                        
                                                                                                <!-- Master Formula calculate Increased Commission -->
                        
                                                <!-- Percent Block -->
                                                                                                                        <!-- Percent Block Ends-->
                                                
                                                <!-- New Section Started -->
                        <div class="exDealsRow">
                            <div class="DealsLeft"><a href="#">Alle Tarife mit einer Grundgebühr bis einschließlich 14,99 €/mtl.</a></div>
                            <div class="DealsMid">
                                
                                                                                            </div>
                            <div class="DealsRight">
                                                                <!-- Exclusive | Show old Commission & Commission -->
                                                                                                12,50
                                
                                                                                            </div>
                            <!-- Details -->
                                                    </div>
                        
                                                                                                <!-- Master Formula calculate Increased Commission -->
                        
                                                <!-- Percent Block -->
                                                                                                                        <!-- Percent Block Ends-->
                                                
                                                <!-- New Section Started -->
                        <div class="exDealsRow">
                            <div class="DealsLeft"><a href="#">Aktionstarife für alle Online Only Tarife</a></div>
                            <div class="DealsMid">
                                
                                                                                            </div>
                            <div class="DealsRight">
                                                                <!-- Exclusive | Show old Commission & Commission -->
                                                                                                5,00
                                
                                                                                            </div>
                            <!-- Details -->
                                                    </div>
                                                <!-- Cleaned -->
                    </div>
                </div>
                                <!-- note: this faq code is also used on the new cashbackcard pages and upcoming faq pages / please include help.css and modernizer.js as mentioned in the head  -->
                <div class="shop-main-details">
                    <div class="cd-faq-items">
                        <ul id="basics" class="cd-faq-group">
                                                                                    <li>
                                <a class="cd-faq-trigger" href="javascript:showbox('cd-faq-content2');">Extra Informationen</a>

                                <div class="cd-faq-content" id="cd-faq-content2" style="display:none;">
                                    <ul class="merchantnotes">
                                                                                <ul>
<li>SATURN Handytarife Cashback erhältst du für tatsächlich getätigte und registrierte Ankäufe, die direkt – ohne zwischenzeitliche Besuche anderer Webshops – und vollständig online – ohne telefonischen oder andersartigen Kontakt mit SATURN Handytarife – abgeschlossen werden. Bitte benutze keine Gutscheincodes von anderen Webseiten und akzeptiere die Cookies vom Partner-Webshop und von unserer Webseite.</li>

<li>Cashback wird anhand der gesamten Kaufsumme exklusive Mehrwertsteuer und anderer hinzukommender Kosten wie Versandkosten, Reservierungs- und Verwaltungsgebühren berechnet.</li>

<li>Ankäufe werden in der Regel innerhalb von 48 Stunden in deinem Benutzer-Konto angezeigt. In seltenen Fällen kann es auch länger dauern. Der Beurteilungszeitraum für Ankäufe variiert je nach Webshop zwischen 2 Wochen bis zu einigen Monaten.</li>

<li>99% der Ankäufe werden korrekt registriert. Trotzdem kann es passieren, dass während der Registrierung deines Ankaufs ein Fehler auftritt. Wenn dies bei dir der Fall ist, bitten wir dich innerhalb von 30 Tagen nach Kaufdatum eine Cashback-Nachbuchung zu beantragen. Ältere Ankäufe können wir leider nicht mehr ermitteln und überprüfen. Für Online-Casinos können keine Nachbuchungsanträge eingereicht werden.</li>
</ul>
                                                                            </ul>
                                </div>
                                <!-- cd-faq-content -->
                            </li>
                                                    </ul>
                        <!-- end cd-faq-group -->
                    </div>
                    <!-- end cd-faq-items -->
                </div>
                <!-- end shop-main-details -->

            </div>
            <!--end shop-main-info -->

            <div class="shop-main-sidebar clearfix">
                <div class="shoptools-title">Shop Tool Box</div>
                <ul class="shoptools">
                    <!-- note: display when not logged in <li><a href="#"><i class="fa fa-power-off" aria-hidden="true"></i>Inloggen | Meld je gratis aan</a></li> -->
                                        <li><a href="/review/saturn-handytarife-de/review.php"><i class="fa fa-pencil" aria-hidden="true"></i>Bewertung schreiben</a>
                    </li>
                                                            <li><a href="/cashback/saturn-handytarife-de.php/favourites"><i class="fa fa-heart"
                                                                                             aria-hidden="true"></i>Zu Favoriten hinzufügen</a>
                    </li>
                                        <li><a href="#" onClick="javascript: NewWinScrolls('/shops/calculate_cashback.php?store=saturn-handytarife-de', 'CalculateCashback', 900, 500);
                            return false;"><i class="fa fa-database" aria-hidden="true"></i>CashCoins berechnen</a>
                    </li>
                                        <li><a class="various" href="#confirmBrokenLink"
                           onclick="javascript: reportBrokenLink('saturn-handytarife-de');"><i class="fa fa-chain-broken"
                                                                                                     aria-hidden="true"></i>Link funktioniert nicht?</a>
                    </li>
                    
                                        <li><a href="/static/alertbar"><i class="fa fa-star" aria-hidden="true"></i>Verfügbar im Cashback-Melder:
                            <i class="fa fa-check" aria-hidden="true"></i></a></li>
                                        <li class="shoptool-social">
                                                                                                                                                                                                
                                            </li>
                </ul>
            </div>
                    </div>
        <!-- end shop-main-intro -->

       
                <div style="clear:both;"></div>
        <div id="alertbar-banner">
            <div id="alertbar-banner-image"><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16//assets/cbk-alertbar-banner.png" alt="cbk-alertbar-banner"
                                                 width="300" height="105"></div>
            <div id="alertbar-banner-text"><strong>Schau in welchen Shops du Cashback erhälst, während du im Internet surfst.</strong>
                <a class="various button" href="/static/toolbar.php"
                   style="float: none; display: inline-block; cursor:pointer; margin: 0 auto"><span>Nutze unsere kostenlosen Cashback-Melder<i
                            class="fa fa-angle-double-right" aria-hidden="true"></i></span></a>
            </div>
        </div>
        
        <div class="shop-main-deals-wrapper clearfix" id="storeDetailsVoucher">
             <a name="Kortingscodes" id="Kortingscodes"></a>
            <h2 class="new-heading">
                Angebote und Rabattcodes für SATURN Handytarife</h2>
                            <p>Keine Ergebnisse gefunden</p>
                        </div>
        <!-- end bx-wrapper -->
        <!-- end deals -->

        <!-- start Blogs -->
       
        <div class="blog-overview home clearfix">

                    </div>
        <!-- end Blogs -->
       
        <!-- begin shop reviews -->
        <div id="shop-main-reviews">
                        <span itemscope itemtype="http://data-vocabulary.org/Review-aggregate">
                                 <a name="reviews" id="reviews"></a>
                <h2 class="new-heading"><span itemprop="itemreviewed"> SATURN Handytarife</span>
                    Bewertungen
                    <span class="shop-main-rating"><span itemprop="count">1</span> Bewertungen</span>
                </h2>

                <div class="store-reviews">
                    <form name="form1" id="addReview" method="post" action="" onsubmit="return validateReview();">
                        <div class="post_reviews">
                            <span class="reviews_label"><span>Bewertung </span></span>
                            <span class="reviews_input">
                                <div class="br-wrapper br-theme-fontawesome-stars">
                                    <select id="rating" class="reviewrating" style="display: none;">
                                        <option value=""></option>
                                        <option value="1">sehr schlecht</option>
                                        <option value="2">schlecht</option>
                                        <option value="3">gut</option>
                                        <option value="4">sehr gut</option>
                                        <option value="5">hervorragend</option>
                                    </select>
                                </div>
                            </span>
                        </div>
                        <div class="post_reviews">
                            <span class="reviews_label"><span>Preis</span></span>
                            <span class="reviews_input">
                                <div class="br-wrapper br-theme-bars-movie">
                                    <select id="priceRating" class="reviewratingbar" style="display: none;">
                                        <option value=""></option>
                                        <option value="1">sehr schlecht</option>
                                        <option value="2">schlecht</option>
                                        <option value="3">gut</option>
                                        <option value="4">sehr gut</option>
                                        <option value="5">hervorragend</option>
                                    </select>
                                </div>
                            </span>
                        </div>
                        <div class="post_reviews">
                            <span class="reviews_label"><span>Versandkosten</span></span>
                            <span class="reviews_input">
                                <div class="br-wrapper br-theme-bars-movie">
                                    <select id="shippingRating" class="reviewratingbar" style="display: none;">
                                        <option value=""></option>
                                        <option value="1">sehr schlecht</option>
                                        <option value="2">schlecht</option>
                                        <option value="3">gut</option>
                                        <option value="4">sehr gut</option>
                                        <option value="5">hervorragend</option>
                                    </select>
                                </div>
                            </span>
                        </div>
                        <div class="post_reviews">
                            <span class="reviews_label"><span>Service</span></span>
                            <span class="reviews_input">
                                <div class="br-wrapper br-theme-bars-movie">
                                    <select id="serviceRating" class="reviewratingbar" style="display: none;">
                                        <option value=""></option>
                                        <option value="1">sehr schlecht</option>
                                        <option value="2">schlecht</option>
                                        <option value="3">gut</option>
                                        <option value="4">sehr gut</option>
                                        <option value="5">hervorragend</option>
                                    </select>
                                </div>
                            </span>
                        </div>
                        <div class="post_reviews">
                            <span class="reviews_label"><span>Cashback-Geschwindigkeit</span></span>
                            <span class="reviews_input">
                                <div class="br-wrapper br-theme-bars-movie">
                                    <select id="cashbackRating" class="reviewratingbar" style="display: none;">
                                        <option value=""></option>
                                        <option value="1">sehr schlecht</option>
                                        <option value="2">schlecht</option>
                                        <option value="3">gut</option>
                                        <option value="4">sehr gut</option>
                                        <option value="5">hervorragend</option>
                                    </select>
                                </div>
                            </span>
                        </div>
                    </form>

                </div>

                <div class="shop-main-sidebar-header clearfix">
                    <span itemprop="rating" itemscope itemtype="http://data-vocabulary.org/Rating">


                        <span class="shop-main-rating-link"><a href="/review/saturn-handytarife-de/review.php"><i
                                    class="fa fa-pencil" aria-hidden="true"></i> Schreibe eine neue Bewertung und bekomme eine Vergütung</a></span>
                    </span>

                </div>
                            </span>
                        <div id="shop_reviews" class="clearfix">
                <!-- Begin Review 1 -->
                                                <div class="shop_review">
                    <div class="shop_review_summary">
                        <i class="fa fa-user"></i>
                        Maxim Batov &nbsp;|&nbsp;02/03/18
                        &nbsp;  15:41:50&nbsp;|&nbsp;Shopbewertung :
                        <img src='https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/star/new/rating_10.png'
                             title='Shopbewertung : 10'
                             class=\"shop_score\"/>
                    </div>
                    <span class="shop_review_text">
                        Bei Saturn habe ich nur Spitzenqualität erlebt. Super große Auswahl und sehr gute Preise. Ich bin ein treuer Kunde von Saturn und wenn der Service weiterhin so gut bleibt, werde ich es auch noch sehr lange bleiben.
                    </span>
                                    </div>
                                            </div>
            <div class="shop_review_all"><a href="/review/saturn-handytarife-de.php">Alle Bewertungen anschauen</a>
            </div>
        </div>
        <!-- end shop reviews -->


        <!-- note: new other also watched -->

        <!-- All shops -->
       
        <div class="ShopDetWebshop"> 

            <h2 class= "new-heading">Ähnliche Webshops</h2>
                                                            <a href="/cashback/vodafone-mobilfunk.php">
                <div class="WebShopBox">
                    <div class="WebShopBoxHd">91,00 CashCoins</div>
                    <div class="WebShopBoxImg"><img src="https://static.orangebuddies.nl/image/stores/7701.jpg" alt=""></div>
                    <div class="WebShopLable">Vodafone (Mobilfunk & Data)</div>
                </div>
            </a>
                                                            <a href="/cashback/vodafone-dsl.php">
                <div class="WebShopBox">
                    <div class="WebShopBoxHd">91,00 CashCoins</div>
                    <div class="WebShopBoxImg"><img src="https://static.orangebuddies.nl/image/stores/7710.jpg" alt=""></div>
                    <div class="WebShopLable">Vodafone (DSL, LTE & TV)</div>
                </div>
            </a>
                                                            <a href="/cashback/o2-de.php">
                <div class="WebShopBox">
                    <div class="WebShopBoxHd">90,00 CashCoins</div>
                    <div class="WebShopBoxImg"><img src="https://static.orangebuddies.nl/image/stores/90640.jpg" alt=""></div>
                    <div class="WebShopLable">O2</div>
                </div>
            </a>
                                                            <a href="/cashback/verivox.php">
                <div class="WebShopBox">
                    <div class="WebShopBoxHd">25,00 CashCoins</div>
                    <div class="WebShopBoxImg"><img src="https://static.orangebuddies.nl/image/stores/34193.jpg" alt=""></div>
                    <div class="WebShopLable">Verivox</div>
                </div>
            </a>
                                                            <a href="/cashback/blau-mobilfunk-de.php">
                <div class="WebShopBox">
                    <div class="WebShopBoxHd">37,50 CashCoins</div>
                    <div class="WebShopBoxImg"><img src="https://static.orangebuddies.nl/image/stores/90634.jpg" alt=""></div>
                    <div class="WebShopLable">blau Mobilfunk</div>
                </div>
            </a>
            

        </div>

        <!-- gifts cards--->
            </div>
    <!-- end all shops -->

</div><!-- end webshops-detail div -->
</div>

<script>
            window.onscroll = function() {myFunction()};
            var navbar = document.getElementById("FixTab");
            var sticky = navbar.offsetTop;
            function myFunction() {
            if (window.pageYOffset >= sticky) {
            navbar.classList.add("sticky")
            } else {
            navbar.classList.remove("sticky");
            }
            }
</script>
    <div class="footerbanner 
         "> &nbsp;

                                                                                                                         
                <a class="various" href="#inline_store_visit" onclick="loginFancyPopUP({cashback: '25,00 ', storeName: 'TARIFCHECK Kfz-Versicherung', urlKey: 'tarifcheck24-kfz', imgUrl: 'https://static.orangebuddies.nl/image/stores/25503.jpg', itemId: '0', bannerId: '35654', isCbkDay: '1'})"> 
                      
                        <img src="https://static.orangebuddies.nl/image/banners/35654-Normal.jpg" alt="TARIFCHECK Kfz-Versicherung">
                                    </a> 
                     

         
    </div>
</div>
<!-- End Content -->
</div>
</div>
<!-- End Main -->
<div id="footer">
    <div class="FooterDetail">
        <div class="FooterQuickLink">
            <div class="FooterMenu">
                <ul class="grid effect-1" id="grid">

                    <li>
                        <p>Angebote</p> 
                        <p class="FooterMenuLink"><a href="/shops/dailydeals-service.php" target="_self">Tagesangebote</a></p>
                        <p class="FooterMenuLink"><a href="/shops/deals.php?type=kortingscodes" target="_self">Rabattcodes </a></p>
                        <p class="FooterMenuLink"><a href="/shops/deals.php?type=new" target="_self">Neue Angebote</a></p>                                      
                        <p class="FooterMenuLink"><a href="/shops/deals.php?type=tip" target="_self">Beliebte Angebote</a></p>
                        <p class="FooterMenuLink"><a href="/shops/deals.php?type=special" target="_self">Sonderangebote</a></p>
                            
                        <p class="FooterMenuLink"><a href="/static/manufacturer-cashback/" target="_self">Cashback-Aktionen der Hersteller</a></p>
                    </li>
                    <li>
                        <p>Hilfreiche Webshop-Tipps</p>
                        <p class="FooterMenuLink"><a href="/static/page.php?url_key=uitleg-shops" target="_self">Wie das Einkaufen mit Cashback funktioniert</a></p>
                        <p class="FooterMenuLink"><a href="/static/page.php?url_key=uitleg-kortingscodes" target="_self">Rabattcodes und Cashback</a></p>
                        <p class="FooterMenuLink"><a href="/shops/shops.php?url_key=all" target="_self">Suche nach Online-Shops </a></p>
                        <p class="FooterMenuLink"><a href="/shops/shops.php?url_key=all" target="_self">Alle Online-Shops mit Cashback</a></p>
                        <p class="FooterMenuLink"><a href="/static/earn-money.php" target="_self">Alle Wege, um Geld zu verdienen</a></p>
                        <p class="FooterMenuLink"><a href="/comparison/" target="_self">Vergleich</a></p>
                        <p class="FooterMenuLink"><a href="/static/page.php?url_key=uitleg-verdien-meer" target="_self">Sofort Verdienst</a></p>
                        <p class="FooterMenuLink"><a href="/user/cashboost-new.php" target="_self">Cashboost</a></p>
                        <p class="FooterMenuLink"><a href="/shops/win-competition.php" target="_self">Gewinnen</a></p>
                        <p class="FooterMenuLink"><a href="/shops/shops.php" target="_self">Gratis Cashback</a></p>
                        <p class="FooterMenuLink"><a href="/blog/" target="_self">Blog</a></p>
                    </li>
                    <li>
                        <p>Hilfe</p>
                        <p class="FooterMenuLink"><a href="/static/faq.php" target="_self">FAQ </a></p>
                        <p class="FooterMenuLink"><a href="/user/generateticket.php"  target="_self">Antrag für fehlende Transaktion stellen</a></p>
                        <p class="FooterMenuLink"><a href="/static/contact.php" target="_self">Anfrage stellen </a></p>
                    </li> 
                    <li>
                        <p>Tools</p>
                                                    <p class="FooterMenuLink"><a href="/static/mobile-app.php" target="_self">App installieren</a></p>
                                                    <p class="FooterMenuLink"><a href="/static/toolbar.php" target="_self">Cashback-Melder downloaden </a></p>
                        <p class="FooterMenuLink"><a href="/tech-check" target="_self">PC Check</a></p>
                    </li>
                    <li>
                        <p>CashbackDeals.de</p> 
                        <p class="FooterMenuLink"><a href="/static/about-us/" target="_self">Über uns</a></p>
                        <p class="FooterMenuLink"><a href="/static/affiliates/" target="_self">Affiliates</a></p>
                            
                        <p class="FooterMenuLink"><a href="/static/advertise/" target="_self">Werben</a></p>
                        <p class="FooterMenuLink"><a href="/static/sitemap/" target="_self">Sitemap </a></p>
                    </li>
                    <li>
                        <p>Allgemein</p>
                        <p class="FooterMenuLink"><a href="/static/terms-and-conditions/" target="_self">AGB</a></p>
                        <p class="FooterMenuLink"><a href="/static/cookies/" target="_self">Cookies</a></p>
                        <p class="FooterMenuLink"><a href="/static/privacy" target="_self">Datenschutz</a></p>
                        <p class="FooterMenuLink"><a href="/static/disclaimer/" target="_self">Disclaimer</a></p>
                        <p class="FooterMenuLink"><a href="/static/impressum/" target="_self">Impressum</a></p>                    
                    </li>
                </ul>
                <script src="/general.assets/js/masonry.pkgd.min.js"></script>
                <script src="/general.assets/js/imagesloaded.js"></script>
                <script src="/general.assets/js/classie.js"></script>
                <script src="/general.assets/js/AnimOnScroll.js"></script>
                <script>
                    new AnimOnScroll(document.getElementById('grid'), {
                        minDuration: 0.4,
                        maxDuration: 0.7,
                        viewportFactor: 0.2
                    });
                </script>
            </div>
        </div>
        <div class="FollowUs">
            <p class="FootHead">Folge uns:</p>
                            <div class="SocialIcons"><a target="_blank" href="https://www.youtube.com/channel/UCiATlA546p52hrcltj3DIBQ"><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/follow-us-youtube.gif" alt="Youtube" class="IconAdj"> Folge uns auf YouTube</a></div>
                                                                            <div class="SocialIcons"><a target="_blank" href="https://www.facebook.com/www.cashbackdeals.de/"><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/follow-us-facebook.gif" alt="Facebook" class="IconAdj"> Like unsere Facebook-Seite</a></div>
                                <div class="rating">
                            </div>

            <div class="OtherLogo">
                <img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/comodo.png" alt="Comodo secure">
            </div>

            <div class="OtherLogo">
                <a href="http://www.keurmerk.info/winkel_detail.php?winkel_id=3868&amp;hfst_id=123" target="_blank">
                    <img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/LogoKeurmerk.png" alt="Webshop Keurmerk">
                </a>
            </div>
        </div> 
    </div>
    <div class="FootSection2">
        <div class="OrangeLogo"><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/OrangeBuddies-logo.png"  alt="OrangeBuddies"></div>
        <div class="copyRight01">
            <p>&copy; 2009-2018 orangebuddies.com | Powered by : <a href="http://www.orangebuddies.com" target="_blank">OrangeBuddies Media</a></p>                       
            <p>CashbackDeals.de ist eine von vielen Cashback-Webseiten von OrangeBuddies Media, einem Online-Medienunternehmen, das seit seiner Gründung im Jahre 2009 zu einem internationalen Unternehmen, mit Standorten in den Niederlanden, Deutschland, Spanien, Großbritannien und Kanada herangewachsen ist. Mit mehr als 100 Cashback-Webseiten in Europa, Australien und den Staaten. OrangeBuddies Media spezialisiert sich in Online-Cashback & Bonus-Portalen mit dem Ziel, Mehrwert für Verbraucher und Anzeigenkunden zu bieten.</p>
        </div>
        <div class="Celebrating">
            <img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/Years10.png" alt="">
            <p>10-jähriges Jubiläum im Jahr 2018</p>
        </div>
    </div>
</div>
            <div class="BottomBar" id="BottomBar">
            <div class="crossBtn"><img onclick="closeDealBar('BottomBar')" style="cursor: pointer;"  src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/crossBtn.png" alt="Close" width="26" height="26" /></div>
            <div class="BarCont">
                <div class="ParentBar">

                    <div class="BarLogo"><img src="https://static.orangebuddies.nl/image/stores/7240.jpg" alt="RandomDeal" class="LogoRes" /></div>
                                                                                                                                                                                                    <div class="BarCash">bis zu 3,00% CashCoins</div>
                    <div class="BarTxt">5% Rabatt für Neukunden bei zooplus</div>
                    <div class="BarTxt2">Code:<strong>5PRDEAFF</strong></div>
                    <div class="ShopNow">
                                                    <a class="various" href="#inline_store_visit"
                               onclick="loginFancyPopUP({cashback: '3,00%', storeName: 'zooplus', urlKey: 'zooplus', imgUrl: 'https://static.orangebuddies.nl/image/stores/7240.jpg', isCbkDay: '1', itemId: '449352'})">
                                Zum Online-Shop
                            </a>
                                            </div>
                </div>
            </div>      
        </div>
    


 <!-- Takeover different banner code start -->
           <!-- Takeover different banner code end -->
     
<div class="rightBanner main_banner">
                                                                                                        <a class="various" href="#inline_store_visit" onclick="loginFancyPopUP({cashback: '4,00%', storeName: 'Under Armour', urlKey: 'under-armour-de', imgUrl: 'https://static.orangebuddies.nl/image/stores/85175.gif', itemId: '0', bannerId: '35626', isCbkDay: '0'})" title="Under Armour"><img class="main_sidebanner"  width="120" height="400" src="https://static.orangebuddies.nl/image/banners/35626-SkyScraperWrapper.jpg" alt="Under Armour" /></a> 
                                    <img src="" width="0" height="0" style="display:none"/>
        </div>
</section> <!-- bodyWrapper section end -->


<!-- PeanutLabs Alert Starts-->
    <script type="text/javascript" src="/general.assets/js/peanut/alert.js"></script>
    
        <script type="text/javascript">

            function initAlert() {
                console.log('fire-peanutalert');
                PeanutLabsAlert.initialize({
                    userId: document.getElementById('user_id').value,
                    debugEnabled: true, // Have debug messages logged to the consolse.
                    hideAfter: 15, // Makes the alert hide after 4 seconds. Can be left out, and will default to 10 seconds.
                    iframeURL: 'https://www.cashbackdeals.de//onlinepanel-pl', // This URL needs to be changed to the url for the iframe.
                    positionHorizontal: 'right',
                    positionVertical: 'bottom',
                    currencyName: 'Peanuts',
                    server: 'https://api.peanutlabs.com',
                    logoURL: 'https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16//assets/osn-icon.png', //'https://ii.peanutlabs.com/PL_Logo.png'
                    alertTitle: 'Neue Umfragen stehen zur Verfügung!',
                    alertMessage: 'Verdiene zusätzliche CashCoins!',
                    alertClickHere: 'Klicke hier'
                });

            }
            $(document).ready(function () {
                initAlert();
                document.cookie = "peanutAlert=0;-1;path=/";
            });
        </script>
    
    <input id="user_id" type="text" value="92385-9261-c7c25349ba" class="form-control" style="display: none;" placeholder="User Id" readonly>
<!-- PeanutLabs Alert Ends -->


        
        <script type="text/javascript">
         //console.log('Lived');
            function reportBrokenLink(urlKey) {
                var htm = '<a href="/report/' + urlKey + '.php" id="reported-link">report</a>';
                jQuery('#genStoreLink').html(htm);
                loadPopup('.various', '680', '215','genStoreLink');
            }

             function fulcrumSurveySent(user_id, survey_number, site_id){
                $.ajax({
                    url: '/ajax/saveFulcrumSurveySent.php',
                    data: 'user_id=' + user_id + '&survey_number=' + survey_number + '&site_id=' + site_id,
                    type: 'POST',
                    success: function (resp) {
                         location.reload();
                         //console.log(resp);   
                    }
                });        
            }
            
            function addToFav(id, type, obj) {

                $.ajax({
                    url: '/ajax/addToFav.php',
                    data: 'action=addToFav&id=' + id + '&type=' + type,
                    type: 'POST',
                    success: function (resp) {
                        if(type=='outfit'){
                           
                           if (resp == 1) {
                                $("#" + obj + id).find('img').attr('src', 'https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/fav-full.png');
                             } else {
                                $("#" + obj + id).find('img').attr('src', 'https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/fav-empty.png');
                             }
                        }else{
                            if (resp == 1) {
                            $("#" + obj + id).addClass('fav-icon-active');
                            } else {
                                $("#" + obj + id).removeClass('fav-icon-active');
                            }
                        }
                        
                    }
                });
            }
            
               function updateWishList(id ,type,selection) {
                 var action = '';

                 ////////////////////// classes used///////////////
                 var enableClsFav           = 'fa-heart'; //enable fav class
                 var disableClsFav          = 'fa-heart-o'; //disable fav class
                 var enableClsFavBell       = 'fa-bell'; //enable mail subscribe class
                 var disableClsFavBell      = 'fa-bell-slash'; //disable mail subscribe class
                 var favId                  = 'favStore';
                 var favNotifyId            = 'favNotify';
                 var commonClsNotify        = 'bellicon';
                 var commonClsHeart         = 'hearticon';
                 var subAllFavId         = 'subscribe_all_fav';
                 
                   if (selection == 'all'){//only work for mail notify bell subscribe
                        var favElementNotifyBell = $("." + commonClsNotify);
                    } else{
                        var favElementHeart  = $("#"+favId+ id);//add favourite element selection need to update
                        var favElementNotifyBell = $("#"+favNotifyId+ id);//subscribe element selection need to update
                    }
                    
                    if(type=='addRemoveFav'){//if user clicked on add fav heart icon
                        if (favElementHeart.hasClass(enableClsFav)) {action = 'remove';} else {action = 'add';}
                     } else if (type == 'updateAlerts'){//if user clicked on fav store mail bell icon notification
                         
                    if(selection=='all'){// if click enable all and disable all mail notifictaions
                           if($("#"+subAllFavId).is(':checked')){action = '1'; } else{action = '0'; }
                        } else{
                           if (favElementNotifyBell.hasClass(disableClsFavBell)) { action = '1'; } else if (favElementNotifyBell.hasClass(enableClsFavBell)) { action = '0'; }
                        }
                    }
                    
                    
                $.ajax({
                    url: '/ajax/update_user_whishlist.php',
                    data: 'action='+action+'&id=' + id + '&type=' + type+'&selection='+selection,
                    type: 'POST',
                    dataType: "json",
                    success: function (resp) {
                        
                      
                        if(type=='addRemoveFav'  && resp==1){
                              
                                if(action=='add'){
                                    favElementHeart.addClass(enableClsFav);
                                    favElementHeart.removeClass(disableClsFav);
                                    favElementNotifyBell.addClass(enableClsFavBell);
                                    favElementNotifyBell.removeClass(disableClsFavBell);
                                }else{
                                    favElementHeart.addClass(disableClsFav);
                                    favElementHeart.removeClass(enableClsFav);
                                    favElementNotifyBell.removeClass(enableClsFavBell);
                                    favElementNotifyBell.addClass(disableClsFavBell);
                                 }
                                    
 
                        }else if(type == 'updateAlerts' && resp>0){
                         
                            if(action=='1'){
                                    favElementNotifyBell.addClass(enableClsFavBell);
                                    favElementNotifyBell.removeClass(disableClsFavBell);
                                }else{
                                    favElementNotifyBell.removeClass(enableClsFavBell);
                                    favElementNotifyBell.addClass(disableClsFavBell);
                                }
                            
                     
                        } 
                       $('#totalunsubs').html($('.'+enableClsFavBell).length);
                        $('#totalsubs').html( $('.'+disableClsFavBell).length);
                        
                    }
                });
            }
            
            function rewardCpcClick(key,pIdx) {
                if (typeof key !== "undefined") {
                    $('#errorbox, #successbox').html('').hide();
                    var errMsg = '';
                    var succMsg = '';
                    $.ajax({
                        url: '/ajax/rewardCpcClick.php',
                        data: 'url_key=' + key,
                        type: 'POST',
                        success: function (resp) {
                            if (resp !== '') {
                                if ($(resp).text() == 'reward_success') {
                                    succMsg = 'Dein Klick wurde erfolgreich registriert und deine Vergütung wurde deinem Konto gutgeschrieben.';
                                } else if ($(resp).text() == 'reward_failed') {
                                    errMsg = 'Dein Klick wurde nicht registriert.';
                                } else if ($(resp).text() == 'already_rewarded') {
                                    errMsg = 'Du hast dieses Angebot bereits angeklickt.';
                                } else if ($(resp).text() == 'store_zero_reward') {
                                    errMsg = 'Dieser Online-Shop vergibt zurzeit kein Cashback.';
                                }
                            } else {
                                errMsg = 'Keine Ergebnisse gefunden';
                            }
                        },
                        async: false
                    });
                    window.open('/visit/' + key + '.php?cm=1', "_blank");// cm=1 mean don't show the exit page;
                    $('.cpc-' + pIdx).remove();
                } else {
                    errMsg = "Keine Ergebnisse gefunden";
                }
                if (errMsg !== '') {
                    $('#errorbox').html(errMsg);
                    $('#errorbox').show();
                }
                if (succMsg !== '') {
                    $('#successbox').html(succMsg);
                    $('#successbox').show();
                }
                $('html,body').scrollTop(0);
                return false;
            }
            
            function adventSaveClick(myObj){
               // console.log("here save click function"+myObj.saveClick);
                
                if(myObj.saveClick){
                   //  console.log("Yes save click!");
                       $.ajax({
                    url: '/ajax/saveAdventClicks.php',
                    data: 'eventid=' + myObj.eventid + '&adventid=' + myObj.adventid+ '&compid=' + myObj.compid,
                    type: 'POST',
                    success: function (resp) {
                        
                        if(resp!=""){
                           return resp;
                        }
                    
                
                       //  console.log('clicked saved');
                         
                    }
                }); 
                }else{
                   //  console.log("Save No click!");
                }
              
                
                    
            }
            function adventCalenderPopup(myObj){
           
                     adventSaveClick(myObj);
                     $('#click').attr('href', myObj.url);
                     $('#click').attr('target','_blank');
                    $('#advent_imgurl').attr('src', myObj.imgUrl);
                    $('#inline_adventCal').css('min-width','650px').css('min-height','550px');
                    loadPopup('.various', '650', '650','adventCalenderpopup');



            }
            
            
            function showReasonField(isShow){
                if(isShow == 0){
                    document.getElementById('otherMsgContainer').style.display = 'none';
                }else{
                    document.getElementById('otherMsgContainer').style.display = 'block';
                }
            }
            function regFancyPopUP(myObj) {
                var landingLink = '/popup/visit.php?url_key=' + myObj.urlKey;
                var show_goto_store_link = 0;
                var imageUrl = "/general.assets/images/bx_loader.gif";
                 
                if (myObj.channel && myObj.channel === "FBC") {
                    landingLink += '&channel=FBC';
                } else if (myObj.channel && myObj.channel === "TOB") {
                    landingLink += '&channel=TOB';
                }
                if (typeof myObj.itemType !== "undefined" && myObj.itemType == 'dagdeal')
                    landingLink += '&type=dagdeal&typeId=' + myObj.itemId;
                else if (typeof myObj.itemType !== "undefined" && myObj.itemType == 'holidaydeal')
                    landingLink += '&type=holidaydeal&typeId=' + myObj.itemId;
                else if (typeof myObj.itemType !== "undefined" && myObj.itemType == 'dailydeal')
                    landingLink += '&type=dailydeal&typeId=' + myObj.itemId;
                else if (typeof myObj.itemType !== "undefined" && myObj.itemType == 'citydeal')
                    landingLink += '&type=citydeal&typeId=' + myObj.itemId;
                else if (typeof myObj.itemType !== "undefined" && myObj.itemType == "product")
                    landingLink = '/product/visit/' + myObj.itemId;
                else if (typeof myObj.itemType !== "undefined" && myObj.itemType == "pfproduct")
                    landingLink = '/pfproduct/visit/' + myObj.itemId;
                else if (typeof myObj.itemId !== "undefined" && myObj.itemId != 0){
                        landingLink += '&type=voucher&typeId=' + myObj.itemId;
                }
                //Only for website banners
                if (typeof myObj.bannerId !== "undefined" && myObj.bannerId != 0) {
                    if (myObj.channel && myObj.channel === "TOB") {
                        landingLink += '&toBannerId='+myObj.bannerId;
                    } else {
                        landingLink += '&bannerId='+myObj.bannerId;
                    }
                }
                //for blogs
                if (typeof myObj.blogId !== "undefined" && myObj.blogId != 0) {
                     landingLink += '&blogId=' + myObj.blogId;
                 }
                 //End Only for website banners
                   if (typeof myObj.themeId !== "undefined" && myObj.themeId != 0)
                           landingLink += '&themeId='+myObj.themeId;

                if (typeof myObj.itemType !== "undefined" && myObj.itemType == "product") {
                    var storeDetailLink = '/product/' + myObj.urlKey + '.php';
                } else if (typeof myObj.itemType !== "undefined" && myObj.itemType == "pfproduct") {
                    var storeDetailLink = 'pfproduct/' + myObj.urlKey + '.php';
                } else if (typeof myObj.itemType !== "undefined" && myObj.itemType == "voucher" && typeof myObj.voucher_url_key !== "undefined") {
                    var storeDetailLink = '/kortingsactie/'+ myObj.urlKey +'/'+ myObj.voucher_url_key;
                } else {
                    var storeDetailLink = '/cashback/' + myObj.urlKey + '.php';
                }

                if(typeof myObj.isCbkDay != 'undefined' && myObj.isCbkDay == 1){
                    var htm = $('#title_popup_cbk_day').val().replace('//1', myObj.cashback).replace('//2', myObj.storeName);
                }
                else{
                    var htm = $('#title_popup').val().replace('//1', myObj.cashback).replace('//2', myObj.storeName);
                }

                var visitHtml = '<a style="margin-left: 2px;" class="button" href="' + landingLink + '" target="_blank" onClick="closePopup()"><span>' + 'Nein, ohne Cashback weiter zum Shop' + '</span></a>';
                var newVisitHtml = '<a href="' + landingLink + '" target="_blank" onClick="closePopup()">Nein, ohne Cashback weiter zum Shop' + '</a>';

                var currurl = window.location.pathname;
                var index = currurl.lastIndexOf("/") + 1;
                var filename = currurl.substr(index);
                var backStoreHtml = '<br/><br/><br/><p><a href="' + storeDetailLink + '" > Zurück CashbackDeals.de</a></p>';
                $('.backlink').html(visitHtml + backStoreHtml);
                  $('.popup-back-right').html('<img src="'+imageUrl+'"  width="16" height="16" alt="-----" title="" />');
              
                  if (typeof myObj.cultureid !== "undefined" && myObj.cultureid != 0 && myObj.cultureid != '9'){
                      $('.popup-back-left').html('');
                        $('.popup-back-right').html('');
                  }
                  else{
                        $('.popup-back-left').html('<a href="' + storeDetailLink + '" > Zurück CashbackDeals.de</a>');
                             $.ajax({
                    url: '/ajax/get_store_checks.php',
                    data: 'url_key=' + myObj.urlKey ,
                    type: 'POST',
                    success: function (resp) {
                          
                        var data = JSON.parse(resp);
                       show_goto_store_link = data.show_goto_store_link ;
                        // console.log('show_goto_store_link:'+show_goto_store_link);
                                if(show_goto_store_link=='1'){
                          //           console.log('yes show_goto_store_link');
                                     $('.popup-back-right').html(newVisitHtml);
                                 }  
                                 else if (typeof myObj.cultureid !== "undefined" && myObj.cultureid != 0 && myObj.cultureid != '9'){
                                     $('.popup-back-right').html('');
                                }
                                 else{
                            //         console.log('not how show_goto_store_link');
                                     $('.popup-back-right').html('');
                                 }
                    }
                });
                  }
                 //   if(show_goto_store_link=='1'){
                    //$('.popup-back-right').html(newVisitHtml); 
                   // }
                  
                  
                ///////////Start hide Show Go to Store Link code show_goto_store_link ////////////
             
               
           
                ///////////End hide Show Go to Store Link code show_goto_store_link ////////////
                
                
                
                $('#reg_main_title').html(htm);
                if (filename == 'dailydeals-service.php')
                    $('.ReturnUrl').val(landingLink);
                else
                    $('.ReturnUrl').val(storeDetailLink);
                visitHtml + backStoreHtml
                loadPopup('.various', '900', '664');
                
            }

            function loginFancyPopUP(myObj) {
        
        hideNewDeals();
                if (myObj.itemType == 'product') {
                    $('#store_cashback_range').html(myObj.cashback);
                    $('.shop-detail-rating').css('display', 'none');
                    $('#extra_conditions').css('display', 'none');
                    if (typeof myObj.itemId !== "undefined" && myObj.itemId != 0)
                       var landingLink = '/product/visit/' + myObj.itemId;
                    $('a#store_visit_link').attr('href', landingLink);
                    $('#store_detail_link').attr('href', '/product/' + myObj.urlKey+'.php');
                } else if (myObj.itemType == 'pfproduct') {
                    $('#store_cashback_range').html(myObj.cashback);
                    $('.shop-detail-rating').css('display', 'none');
                    $('#extra_conditions').css('display', 'none');
                    if (typeof myObj.itemId !== "undefined" && myObj.itemId != 0)
                       var landingLink = '/pfproduct/visit/' + myObj.itemId;
                    $('a#store_visit_link').attr('href', landingLink);
                    $('#store_detail_link').attr('href', '/pfproduct/' + myObj.urlKey+'.php');
                } else {
                    var storeDetailLink = null;
                    if (myObj.itemType == 'voucher' && typeof myObj.voucher_url_key !== 'undefined') {
                        storeDetailLink = '/kortingsactie/'+ myObj.urlKey +'/'+ myObj.voucher_url_key;
                    } else {
                        storeDetailLink = '/cashback/'+myObj.urlKey+'.php';
                    }
                    var landingLink = '/popup/visit.php?url_key='+myObj.urlKey;
                 
                     if(typeof myObj.cultureid !== "undefined" && myObj.cultureid != 0  && myObj.cultureid != '9' ){
                        // alert('hello');
                       
                        landingLink += '&cultureid='+myObj.cultureid;
                        var pasUrl =  "url_key=" + myObj.urlKey + "&cultureid=" + myObj.cultureid;
                    }
                    else{
                        var pasUrl =  "url_key=" + myObj.urlKey;
                    }
                    if (myObj.channel && myObj.channel === "FBC") {
                        landingLink += '&channel=FBC';
                    } else if (myObj.channel && myObj.channel === "TOB") {
                        landingLink += '&channel=TOB';
                    }
                    if (typeof myObj.itemType !== "undefined" && (myObj.itemType == 'dailydeal' || myObj.itemType == 'dagdeal' || myObj.itemType == 'holidaydeal')) {
                       landingLink += '&type='+myObj.itemType+'&typeId='+myObj.itemId;
                    } else if (typeof myObj.itemId !== "undefined" && myObj.itemId != 0) {
                        landingLink += '&type=voucher&typeId='+myObj.itemId;
                    }
                    //Only for website banners
                    if (typeof myObj.bannerId !== "undefined" && myObj.bannerId != 0) {
                        if (myObj.channel && myObj.channel === "TOB") {
                            landingLink += '&toBannerId='+myObj.bannerId;
                        } else {
                            landingLink += '&bannerId='+myObj.bannerId;
                        }
                    }
                    //for blogs
                if (typeof myObj.blogId !== "undefined" && myObj.blogId != 0) {
                     landingLink += '&blogId=' + myObj.blogId;
                 }
                    //End Only for website banners
                      if (typeof myObj.themeId !== "undefined" && myObj.themeId != 0)
                           landingLink += '&themeId='+myObj.themeId;

                    $('#storeVoucherBox').hide(); // hide any previously shown voucher code box
                    if (typeof myObj.itemId !== "undefined"  && typeof myObj.code !== "undefined" && myObj.code != '') {
                        $('#storeVoucherCode').html(myObj.code);
                        $('#storeVoucherBox').show();
                    }

                    $.ajax({
                        url: '/ajax/get_store_detail.php',
                        data: pasUrl,
                        type: 'POST',
                        success: function (resp) {
                            var obj = JSON.parse(resp);
                            var min = obj.cashback_range.min;
                            var max = obj.cashback_range.max;
                            if (min != null) {
                                if (37 == '77' || 37 == '91' || 37 == '133' || 37 == '132') {

                                    min = parseFloat(min).toFixed(2);
                                    max = parseFloat(max).toFixed(2);
                                } else {
                                    min = parseFloat(min).toFixed(2).replace('.', ',');
                                    max = parseFloat(max).toFixed(2).replace('.', ',');
                                }
                            }
                            $('#dealsNew').empty();
                            if(typeof(obj.deals) !="udefined" && obj.deals != null){
                                 var lbl_popup_deal_select = "Auswählen";
                               obj.deals.forEach(function(item){
                                    $('#dealsNew').append('<div class="popup-row">                        <div class="popup-deal-logo">                  <img src="'+item.voucher_image+'"></div>  <div class="popup-deal-store">'+item.name+'</div>  <div class="popup-deal-save">'+item.txt_cashback+'</div> <div class="popup-deal-btn"><a href="/cashback/'+item.url_key+'.php">'+lbl_popup_deal_select+'</a></div></div>');
                               });
                            }
                               if (typeof myObj.cultureid !== "undefined" && myObj.cultureid != 0 && myObj.cultureid != '9'){

            var type = obj.cashback_range.cashback_type; 
              if (type == 'percent')
                                type = "%";
                            else if (type == 'points')
                                type = 'Punkt(e)';
                            else
                                type = '';
             var cashback = obj.cashback_range.cashback;
              if (37 == '77' || 37 == '91' || 37 == '133' || 37 == '132') {

                                    cashback = parseFloat(cashback).toFixed(2);
                                  
                                } else {
                                    cashback = parseFloat(cashback).toFixed(2).replace('.', ',');
                                  
                                }
           //  alert(type);
             //alert(cashback + type);
                
                         $('#store_cashback_range').html(cashback + type);
            }
            else{
                            var type = obj.cashback_range.type;
                            if (type == 'percent')
                                type = "%";
                            else if (type == 'points')
                                type = 'Punkt(e)';
                            else
                                type = '';
                            if (min == null)
                                $('#store_cashback_range').html('0,00');
                            else if (min == max)
                                $('#store_cashback_range').html(min + type);
                            else
                                $('#store_cashback_range').html(min + ' - ' + max + type + ' <a href="' + storeDetailLink + '" class="info_store_deals"><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/info_icon.png" width="30" height="30" style="vertical-align:top;" border="0" alt="" /></a>');
                        }
                            var rating_imgurl = $('#popup_rating_imgurl').val();
                            $('#popup_rating_img').attr('src', rating_imgurl + obj.store_reviews.rating + '.png');
                            $('#popup_total_reviews').html(obj.store_reviews.total_reviews);

                            var extra_info = obj.store_info.cashback_tc;
                            var lbl_extra_conditions_info = 'Ja, <a href="//1" onclick="closeFB()">klicke hier</a>';
                            if (extra_info == false)
                                $('#extra_conditions').html('Nein');
                            else
                                $('#extra_conditions').html(lbl_extra_conditions_info.replace('//1', storeDetailLink + '#additional_conditions'))
                        }
                    });
                    $('a#store_visit_link').attr('href', landingLink);
                     if(typeof myObj.cultureid !== "undefined" && myObj.cultureid != 0 &&  myObj.cultureid  != '9' ){
                       
                         $('#store_detail_link').hide();
                    }
                    else{
                  $('#store_detail_link').show();
                $('#store_detail_link').attr('href', storeDetailLink);
                    }
                  
                }
                // already visited store script
                 var vistedKeys = [];
                                                       vistedKeys.push("");
                                  if((jQuery.inArray( myObj.urlKey,vistedKeys) >= 0 || jQuery.inArray( myObj.urlKey,keyGlobal) >= 0)){
                     var store_short_desc = '<i class="fa fa-check-circle"></i>Wir haben deinen Besuch bei %STORENAME% registriert.';
                 }else{
                     var store_short_desc = 'Deine Bestellung bei //store_name wird nun registriert';

                 }
                 $('#store_visit_link').attr('onclick','setPopupTitle("'+myObj.storeName+'","'+myObj.urlKey+'");');
                 // already visited store script end

                $('.heading').html(store_short_desc.replace("//store_name", '<span>' + myObj.storeName + '</span>').replace("%STORENAME%", '<span>' + myObj.storeName + '</span>'));
                $('.alert-msg').html($('#store_full_desc').val().replace("//store_name", myObj.storeName));
                var lbl_visit_store_btn = "Zu //1";
                $('#store_visit_text').html(lbl_visit_store_btn.replace("//1", myObj.storeName));
                $('#store_imgurl').attr('src', myObj.imgUrl);
                checkPCSettings();
                loadPopup('.various', '900', '664');
            }
            function showNewDeals(){
                $('.popup-deals').show();
                $('.popup-info').hide();
                $('.popup-advice').hide();
                $('.alert-msg').hide();
                $('#storeVoucherBox').hide();
                $('.popup-button').hide();
                $('.popup-back').hide();
            }
            function hideNewDeals(){
                $('#dealsNew').empty();
                $('.popup-deals').hide();
                $('.popup-info').show();
                $('.popup-advice').show();
                $('.alert-msg').show();
                $('#storeVoucherBox').show();
                $('.popup-button').show();
                $('.popup-back').show();
            }
            var keyGlobal = [];
            function setPopupTitle(title,url_key){
                if(jQuery.inArray( url_key,keyGlobal) < 0){
                    keyGlobal.push(url_key);
                }
                var store_short_desc = '<i class="fa fa-check-circle"></i>Wir haben deinen Besuch bei %STORENAME% registriert.';
                $('.heading').html(store_short_desc.replace("%STORENAME%", '<span>' + title + '</span>'));
                showNewDeals();
            }

            function closePopup() {
                document.getElementsByClassName('fancybox-close')[0].click();
            }

            function checkPCSettings() {
                if (!$.adblock && navigator.cookieEnabled)
                    $('#pc_check_status').html('Perfekt! <img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/ok.png">');
                else
                    $('#pc_check_status').html('<a href="/static/tech-check">Klicke hier</a> <img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/cancel.png">');
            }
            function codeVisibility(id, key) {
                document.getElementById("btn_" + id).style.display = "none";
                document.getElementById("code_" + id).style.display = "block";
                //window.open("/visit/"+key+".php","windowName", "width=500,height=500,scrollbars=yes");
            }
            function focusAction(field, value) {
                if (field.value == value) {
                    field.value = '';
                }
            }
            function blurAction(field, value) {
                if (field.value == '') {
                    field.value = value;
                }
            }
            function termsCondition() {
                window.open("/user/terms.php", "windowName", "width=800,height=650,scrollbars=yes");
            }

            function Privacy() {
                window.open("/static/privacy/", "windowName", "width=800,height=650,scrollbars=yes");
            }
            function NewWinScrolls(url, name, w, h) {
                wleft = (screen.width - w) / 2;
                wtop = (screen.height - h) / 2;
                if (win) {
                    if (!win.closed)
                        win.close();
                }
                var win = window.open(url, 'popup', 'width=' + w + ',height=' + h + ',' + 'left=' + wleft + ',top=' + wtop + ',' + 'location=no,menubar=no,' + 'status=no,toolbar=no,scrollbars=yes,resizable=yes');
                // Just in case width and height are ignored
                try {
                    win.resizeTo(w, h);
                    win.moveTo(wleft, wtop);
                } catch (exception) {
                }
                win.focus();
            }
            function searchEvent(elementid) {
                $("#" + elementid).click(function () {
                    if ($("#searchinput").val() == "Zoek shop, product of deal") {
                        $("#searchinput").attr("value", "");
                        return false;
                    }
                    if ($("#searchinput").val() != "") {
                        var url = "/search/search.php?q=" + encodeURIComponent($("#searchinput").val());
                        window.location = url;
                    }
                })
            }
            $("#searchinput").keypress(function (e) {
                code = (e.keyCode ? e.keyCode : e.which);
                if (code == 13 && $("#searchinput").val() != "") {
                    var url = "/search/search.php?q=" + $("#searchinput").val();
                    window.location = url;
                }
            })
            function getSearchResults(value, id, page, type,filterByClass) {
               
                var value = value.replace('&', 'replacedForAnd');
                type = typeof type !== 'undefined' ? type : '';
                
                        var dataString = [];
                        var temp={};
                    if(typeof filterByClass !== "undefined" ){
               
                    $('.'+filterByClass+':checkbox:checked').each(function () {
                        dataString.push($(this).val());
                    });
                }
               // send search var using checked checkbox
               var jsonString = JSON.stringify(dataString);
           
                if (value != '') {
                    $.ajax({
                        url: '/ajax/' + page ,
                        data: "q=" + value + "&t=" + type+ "&filterBy=" + jsonString ,
                        type: 'POST',
                        success: function (resp) {
                            if (value == '') {
                                $("#" + id).hide();
                            } else {
                                $("#" + id).html(resp);
                                $("#" + id).show();
                            }
                        }
                    });
                } else {
                    $("#" + id).hide();
                }
            }
            function getStoreResults(value) {
                if (value != '') {
                    $.ajax({
                        url: '/ajax/store_results.php',
                        data: "t=" + value,
                        type: 'POST',
                        success: function (resp) {
                            if (value == '') {
                                $("#storeResults").hide();
                            } else {
                                $("#storeResults").html(resp);
                                $("#storeResults").show();
                            }
                        }
                    });
                } else {
                    $("#storeResults").hide();
                }
            }
            function getFaqResults(value, id, page) {
                if (value != '') {
                    $.ajax({
                        url: '/ajax/' + page,
                        data: "q=" + value,
                        type: 'POST',
                        success: function (resp) {
                            if (value == '') {
                                $("#" + id).hide();
                            } else {
                                $("#" + id).html(resp);
                                $("#" + id).show();
                            }
                        }
                    });
                } else {
                    $("#" + id).hide();
                }
            }
            /* Note: Added custom Class to Box close button */
            function loadPopup(className, width, height, targetedHtmlId) {
                targetedHtmlId = typeof targetedHtmlId !== 'undefined' ? targetedHtmlId : '';
                if (className == '')
                    className = '.various';
                if (width == '')
                    width = typeof width !== 'undefined' ? width : '891';
                height = typeof height !== 'undefined' ? height : '664';
                className = typeof className !== 'undefined' ? className : '.various';

                var btnTemplate = '';
                if ('Shoppingandmore23@hotmail.com') {
                    switch(targetedHtmlId){
                        case 'genStoreLink':
                            btnTemplate = '<a title="Close" class="fancybox-item fancybox-close fancybox-close-other" href="javascript:;"></a>';
                            break;
                        case 'tellafriends':
                            btnTemplate = '<a title="Close" class="fancybox-item fancybox-close fancybox-close-tellfrnd" href="javascript:;"></a>';
                            break;
                        case 'cashoutpopup':
                            btnTemplate = '<a title="Close" class="fancybox-item fancybox-close fancybox-close-cashoutpopup" href="javascript:;"></a>';
                            break;
                        case 'adventCalenderpopup':
                            btnTemplate = '<a title="Close" class="fancybox-item fancybox-close fancybox-close-adventCalenderpopup" href="javascript:;"></a>';
                            break;
                        default:
                            btnTemplate = '<a title="Close" class="fancybox-item fancybox-close fancybox-close-loggedin" href="javascript:;"></a>';
                    }
                }
                else{
                    btnTemplate = '<a title="Close" class="fancybox-item fancybox-close" href="javascript:;"></a>';

                } 
                $(className).fancybox({
                    maxWidth: width,
                    maxHeight: height,
                    fitToView: false,
                    width: '100%',
                    height: '100%',
                    autoSize: false,
                    closeClick: false,
                    openSpeed: 'fast',
                    closeSpeed: 100,
                    openEffect: 'none',
                    closeEffect: 'none',
                    tpl: {
                        closeBtn:btnTemplate
                    }
                });
            }
                 /* Note: Added custom Class to Box close button */
            function loadPopupWhatsapp(className, width, height) {
                if (className == '')
                    className = '.various';
                if (width == '')
                    width = typeof width !== 'undefined' ? width : '891';
                height = typeof height !== 'undefined' ? height : '664';
                className = typeof className !== 'undefined' ? className : '.various';
                var btnTemplate = '<a title="Close" id="close" class="fancybox-item fancybox-close" href="javascript:;"></a>';

                $(className).fancybox({
                    maxWidth: width,
                    maxHeight: height,
                    fitToView: false,
                    width: '100%',
                    height: '100%',
                    autoSize: false,
                    closeClick: false,
                    openSpeed: 'fast',
                    closeSpeed: 100,
                    openEffect: 'none',
                    closeEffect: 'none',
                    helpers     : {
                        overlay :{closeClick: false}
                    },
                    tpl: {
                        closeBtn:btnTemplate
                    }
                });
            }
            
                        
            function ajaxFancyPopup(ftype){
                 var btnTemplate = '<a title="Close" class="fancybox-item fancybox-close" href="javascript:;"></a>';
           
                $.ajax({
                           url: '/ajax/fancyBox.php',
                            data: "ftype=" + ftype,
                            type: 'POST',
                            success: function (data) {
                                //alert(data);
                           // console.log(resp);
                            $.fancybox(data, {
                            // fancybox API options
                                    width: '100%',
                                    height: '100%',
                                    autoSize: false,
                                    closeClick: false,
                                    openSpeed: 'fast',
                                    closeSpeed: 100,
                                    openEffect: 'none',
                                    closeEffect: 'none',
                                    tpl: {
                                    closeBtn:btnTemplate
                                    }
                            });
                           
                            }
                    });
         
            }//function end ajaxFancyPopup
            
            function replyPopUp(reviewid) {
                $('#reviewid').val(reviewid);
            }
            function toggleTabs(tabid, className) {
                for (var i in tabArray) {
                    if (tabArray[i] == tabid) {
                        $('#' + tabArray[i]).slideDown('slow');
                        $('a#li-' + tabArray[i]).addClass(className);
                    } else {
                        $('#' + tabArray[i]).slideUp('slow');
                        $('a#li-' + tabArray[i]).removeClass();
                    }
                    if (tabid != 'first-content') {
                        $('li#li-first-content').removeClass('active');
                        $('li#li-first-content').addClass('wtab');
                    } else {
                        $('li#li-first-content').addClass('active');
                        $('li#li-first-content').removeClass('wtab');
                    }
                }
            }
            function ShowSBSPopup($sbsPartner){
                    loadPopup('.various', '775', '410');
                        $(".sbsPopupReplace").each(function(){
                            $(this).text($(this).text().replace('%SBS_PARTNER%',$sbsPartner));
                        });

                    return false;
                }
            function closeAccountCBK() {
                    $('form#close').submit();
                    return false;
            }
            function moveAccountToSBS(obj) {
                $.ajax({
                    url: '/ajax/moveAccToSBS.php',
                    data: 'moveAccount=1',
                    type: 'POST',
                    success: function (response) {
                        response = $.parseJSON(response);
                        if (response.status == 'success') {
                            $('form#close').submit();
                        } else if (response.status == 'failure' && response.message == 'user-exist') {
                            var msg = "Du hast bereits ein Mitgliedskonto auf %SBS_PARTNER%";
                            var rMsg = msg.replace('%SBS_PARTNER%', obj.sbsPartner);
                            alert(rMsg);
                        } else {
                            alert('Failed to connect.');
                        }
                    }
                });
                return false;
            }
            function validateEmail() {
                var strEmails = '';
                $("#inline_tellafriends input[type=checkbox]").each(function (index, element) {
                    if ($(this).is(':checked')) {
                        strEmails += $(this).val() + ',';
                    }

                });
                document.cashboostForm.friend_email.value = strEmails.substring(0, (strEmails.length) - 1);
                if (strEmails != '') {
                    document.getElementById('friend_email').readOnly = 'readOnly';
                }
                document.getElementById('forms').style.display = 'block';
                document.getElementById('gmail').style.display = 'none';
                document.getElementById('yahoo').style.display = 'none';
            }
            // Listen for click on toggle checkbox
            $('#select-all').click(function (event) {
                if (this.checked) {
                    $(':checkbox').each(function () {
                        this.checked = true;
                    });
                }
            });
            function getStoreLink(value, title) {
                document.getElementById('store-link').value = value;
                document.getElementById('t').value = title;
                ClipBoard();
            }
            function ClipBoard() {
                if (window.clipboardData) {
                    window.clipboardData.setData('text', document.getElementById('store-link').value);
                }
                document.getElementById('store-link').select();
            }
            function fillPopup(size, image, code, alt, heading) {
                document.getElementById('getCode').innerHTML = '<h2>' + heading + '</h2><table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding: 5px;"><tr><td height="50">Size: ' + size + '</td></tr><tr><td class="code_preview" height="100">Preview:<br /><img src="' + image + '" alt="" /></td></tr><tr><td height="150">Code:<br /><div style="border:1px solid #ccc; padding: 10px; width: 95%;">&lt;a href=&quot;' + code + '&quot;&gt;&lt;img   src=&quot;' + image + '&quot;   alt=&quot;' + alt + '&quot; /&gt;&lt;/a&gt;</div></td></tr></table>';
            }
            function getFieldValidation(field_name, field_hint, minVal) {
                //alert(field_hint);
                minVal = typeof minVal !== 'undefined' ? minVal : 10;
                var friend_email1 = new Spry.Widget.ValidationTextField(field_name, "none", {
                    minChars: minVal,
                    isRequired: true,
                    hint: field_hint,
                    validateOn: ["change", "blur"]
                });
            }
            function getPasswordValidation(field_name, field_hint, minVal) {

                minVal = typeof minVal !== 'undefined' ? minVal : 10;
                var friend_email1 = new Spry.Widget.ValidationPassword(field_name, {
                    minChars: minVal,
                    isRequired: true,
                    hint: field_hint,
                    validateOn: ["change", "blur"]
                });
            }
            function validatePopup(array) {
                var first_name_v = new Spry.Widget.ValidationTextField("first_name_v", "none", {
                    minChars: 3,
                    isRequired: true,
                    hint: array[0],
                    validateOn: ["change", "blur"]
                });
                var last_name_v = new Spry.Widget.ValidationTextField("last_name_v", "none", {
                    minChars: 3,
                    isRequired: true,
                    hint: array[1],
                    validateOn: ["change", "blur"]
                });
                var email_v = new Spry.Widget.ValidationTextField("email_v", "email", {
                    isRequired: true,
                    hint: array[2],
                    validateOn: ["change", "blur"]
                });
                var username_v = new Spry.Widget.ValidationTextField("username_v", "none", {
                    minChars: 3,
                    isRequired: true,
                    hint: array[3],
                    validateOn: ["change", "blur"]
                });
                var password_fv = new Spry.Widget.ValidationTextField("password_fv", "none", {
                    minChars: 5,
                    hint: array[4],
                    isRequired: true,
                    validateOn: ["change", "blur"]
                });
                var password_v = new Spry.Widget.ValidationPassword("password_v", {
                    minChars: 6,
                    maxChars: 20,
                    hint: array[4],
                    isRequired: true,
                    validateOn: ["change", "blur"]
                });
                var email_v2 = new Spry.Widget.ValidationTextField("email_v2", "email", {
                    minChars: 3,
                    isRequired: true,
                    hint: array[5],
                    validateOn: ["change", "blur"]
                });
                var password_v2 = new Spry.Widget.ValidationPassword("password_v2", {
                    minChars: 6,
                    hint: array[6],
                    isRequired: true,
                    validateOn: ["change", "blur"]
                });
                var password_fv2 = new Spry.Widget.ValidationTextField("password_fv2", "none", {
                    minChars: 5,
                    hint: array[6],
                    isRequired: true,
                    validateOn: ["change", "blur"]
                });
            }
            function putSearchValue(value, id, id2) {
                //alert(id);
                $("#" + id).val(value);
                $("#searchList").hide();
            }
            /**
             * Updates name for tell a friend popup
             */
            function updateName(field) {
                $('#new_friend_name').html(field.value);
            }
            function hideTextTip(field, text) {
                if ($(field).val() == text) {
                    $(field).val('');
                }
            }
            function showTextTip(field, text) {
                //alert(field);
                if ($(field).val() == '') {
                    $(field).val(text);
                }
            }
            function showPass(pass, tip) {
                $(pass).show();
                $(tip).hide();
                $(pass).focus();
            }
            function hidePass(pass, tip) {
                if ($(pass).attr('value') == '') {
                    $(tip).show();
                    $(pass).hide();
                }
            }
            var shareChk = '';
            function loadConversionPixel() {
                var clickref = 'clickref'
                $.ajax({
                    type: "POST",
                    url: "/ajax/getFacebookLike.php",
                    data: "task = getFacebookLike&clickref=" + clickref,
                    success: function (result) {
                        $("#ho-pixels").append(result);
                    }
                });
                return false;
            }

            function insertShare(emailAddr, uID, storeid) {
                jQuery.ajax({
                    url: "/ajax/share_result.php",
                    type: "POST",
                    data: {userid: uID, email: emailAddr, sid: storeid},
                    success: function (data) {
                        if (data) {
                            //alert('Share Success');
                            //window.location.href = '';
                            location.reload();
                        }
                    }
                });
            }
            function is_share(uID) {
                shareChk = jQuery.ajax({
                    url: "/ajax/is_share.php",
                    type: "POST",
                    async: false,
                    data: {userid: uID},
                    success: function (data) {
                        if (data) {
                            return data;
                        }
                    }
                }).responseText;
                return shareChk
            }
            function shareDeal(url, name, img, uID, storeid, desc) {
                var result = is_share(uID);
                if ($(result).text() == 'false') {
                    location.reload();
                    return false;
                }
                FB.ui(
                        {
                            method: 'feed',
                            name: name,
                            link: url,
                            picture: img,
                            caption: '',
                            description: desc

                        },
                        function (response) {
                            if (response && !response.error_message) {
                                //FB.api('/me', function(response) {
                                //	console.log(response);
                                //email = response.email;

                                insertShare('', uID, storeid);
                                //});
                            } else {
                                //alert('Post was not published.');
                            }
                        });
            }
            var TweetUserid = '';
            var store_id = '';
            function shareTweet(eleNo, userid, linkurl, text, sid) {
                var result = is_share(userid);
                if ($(result).text() == 'false') {
                    //alert('Share quota exceeded');
                    location.reload();
                    return false;
                } else {
                    TweetUserid = userid;
                    store_id = sid;

                }
                var myurl = linkurl;
                var mytext = text;
                var url = "https://twitter.com/intent/tweet" +
                        "?url=" + encodeURIComponent(myurl) +
                        "&text=" + encodeURIComponent(mytext);

                document.getElementById("shareLink" + eleNo).href = url;
            }
            window.twttr = (function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0],
                        t = window.twttr || {};
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "https://platform.twitter.com/widgets.js";
                fjs.parentNode.insertBefore(js, fjs);

                t._e = [];
                t.ready = function (f) {
                    t._e.push(f);
                };

                return t;
            }(document, "script", "twitter-wjs"));
            twttr.ready(function (twttr) {
                twttr.events.bind('tweet', function (event) {
                    if (event) {
                        if (event.target.id != 'tweetShareLink') {
                            insertShare('', TweetUserid, store_id);
                        }
                    }
                });
            });
            function showTellafriendForm() {
                document.getElementById('forms').style.display = 'block';
                document.getElementById('gmail').style.display = 'none';
                document.getElementById('yahoo').style.display = 'none';
            }
            function getUserResults(value, id, page) {
                if (value != '') {
                    $.ajax({
                        url: '/ajax/' + page,
                        data: "q=" + value,
                        type: 'POST',
                        success: function (resp) {
                            if (value == '') {
                                $("#" + id).hide();
                            } else {
                                $("#" + id).html(resp);
                                $("#" + id).show();
                            }
                        }
                    });
                } else {
                    $("#" + id).hide();
                }
            }
            function displayEmails(email) {
                document.getElementById('email').value = email;
                document.getElementById('userList').style.display = 'none';
            }
            function checkIBAN() {
                var vlink = $('#verify_iban');
                var vr = $('#verification_result');
                var acc = $('#account_number');
                $(document).ready(function () {
                    $('input[name!="account_number"]').focus(function () {
                        vr.slideUp(150);
                    });
                });
                acc.focus(function () {
                    if (vlink.css('display') == 'none') {
                        vlink.fadeIn(200);
                    }
                });
                vlink.click(function (e) {
                    vlink.fadeOut(200);
                    e.preventDefault();
                    //if ($('#account_number').val().trim() != '') {
                        $.ajax({
                            url: '/ajax/verify_iban.php',
                            data: "iban=" + $('#account_number').val().trim(),
                            type: 'POST',
                            beforeSend: function () {
                                vlink.after('<span id="loading">&nbsp; <img src="/general.assets/images/loading.gif" alt="" width="10" height="10" /></span>');
                            },
                            success: function (resp) {
                                vr.html(resp);
                                vr.slideDown(250);
                                $('#loading').remove();
                            }
                        });
                    //}
                });

            }

            function showIbanDetail(){

                 loadPopup('.various', '900', '664');
            }


                /** CASHBACK OF THE DAY INTERVAL **/
                function startIntervalCashback(tabs) {
                    return setInterval(function () {
                        tabs.each(function (idx, ele) { // iteration through each element
                            if (!$(ele).hasClass('active')) {// if element is not active then make that active and display his respective container (Trending or CashbackDay)
                                $(ele).addClass('active');
                                if ($(ele).prop('id') == 'trending') {
                                    $('#Trending').css("display", "block");
                                    $('#Cashbackday').css("display", "none");
                                } else {
                                    $('#Cashbackday').css("display", "block");
                                    $('#Trending').css("display", "none");
                                }
                            } else {
                                $(ele).removeClass('active');
                            }
                        });
                    }, 4000);
                }
                $(document).ready(function () {
                    var tabs = $('.tablinksNew');
                    if (typeof tabs !== "undefined") {
                        var intrValObj = '';// var will be used as a global variable for interval instance
                        if (tabs.length > 1) {// interval will only work if the number of tabs are more then one.
                            intrValObj = startIntervalCashback(tabs);// start interval
                            $('.homehome-banners').mouseenter(function () {
                                clearInterval(intrValObj); // clear interval
                            }).mouseleave(function () {
                                intrValObj = startIntervalCashback(tabs); //restart interval
                            })
                        }
                    }

                    if($('.notifi-icon').length > 0) {
                        var notifyicon = $('.notifi-icon');
                        if (typeof notifyicon !== "undefined") {
                            $(".notifi-icon").click(function () {
                                $(".notifi-list").toggleClass("top-notifi");
                            });
                        }
                    }
                    if($('.tooltipinfo').length > 0) {
                        var tooltipinfo = $('.tooltipinfo');
                        if (typeof tooltipinfo !== "undefined") {
                            $("#tooltipinfo").tooltip({
                                show: {
                                    effect: "slideDown",
                                    delay: 100
                                }
                            });
                        }
                    }
                    
                    $(".searc-SDD").click(function(){
                        $(".searc-SDC").toggle();
                    });
                    
                });
                /** CASHBACK OF THE DAY INTERVAL END **/

            /*function toggleBICCode() {
             var acc = $('#account_number').val();
             var bic_code_block = $('#bic_code_block');
             if(bic_code_block!==undefined && bic_code_block.css('display')=='none' && acc.match(/^(?!NL)[A-Z]+[A-Z]+/)) {
             bic_code_block.fadeIn(200);
             } else if(acc.match(/^(NL)+/)) {
             bic_code_block.fadeOut(150);
             }
             }*/

                /*************Profile questions hide show js **************/
                function hideshowSubQuestion(question_id,selected_answer){
                      var sub_div_id = '#sub-question-' + question_id;
                      var triggerOptions = $(sub_div_id).data('trigger_options');
                      var split_str = triggerOptions.split(",");
                      //alert(split_str);
                      if (split_str.indexOf(selected_answer) !== - 1) {
                      // alert('show sub question div');
                      $(sub_div_id).show();
                      } else{
                      //alert('hide sub question div');
                      $('.' + question_id + '-subcheck').removeAttr('checked');
                      $(sub_div_id).hide();
                      }
                      }
                      
                      
                      
            /** toggle street for cadeaus shop **/
            function toggleStreet() {
                if (document.getElementById('culture').value == 'NL') {
                    $('#street_v').removeClass('textfieldRequiredState');
                    document.getElementById('street').readOnly = true;
                    document.getElementById('street').style.backgroundColor = '#EFEFEF';
                } else {
                    document.getElementById('street').readOnly = false;
                    document.getElementById('street').style.backgroundColor = '';
                }
                // hide error messages occurred in postcode validation
                document.getElementById('invalid_house_number').style.display = 'none';
                document.getElementById('invalid_postcode').style.display = 'none';
            }

           // OneSignal
            function OneSignalUserSubscription(agentID, isSubscribe) {
                jQuery.ajax({
                    url: "/ajax/one_signal_user_subscription.php",
                    type: "POST",
                    data: {agentid: agentID, isSubscribe:isSubscribe},
                    success: function (data) {
                        if (data) {
                         //   console.log(data);
                        }
                    }
                });
            }

            // OneSignalNew
            function OneSignalUserSubscriptionNew(agentID, isSubscribe) {
                jQuery.ajax({
                    url: "/ajax/one_signal_user_subscription_new.php",
                    type: "POST",
                    data: {agentid: agentID, isSubscribe:isSubscribe},
                    success: function (data) {
                        if (data) {
                           // console.log(data);
                        }
                    }
                });
            }

            $(document).ready(function ($) {

                if ('' == true) {
                    $('.alert-popup-wrap').css("display", "block");
                }
				
                $('.alert-popup-exit').click(function () {
                    $('.alert-popup-wrap').css("display", "none");
                })
                
                $('.code-popup-exit').click(function () {
                    $('.code-popup-wrap').css("display", "none");
                })
                if ($('.competition_timer').length != 0) {
                    $('.competition_timer').counter().on('counterStop', function () {
                        $(this).hide();
                    });
                }
                if ($('.bingo_timer').length != 0) {
                    $('.bingo_timer').counter().on('counterStop', function () {
                        $(this).hide();
                    });
                }
                if ($('.exclusive_top_referral_timer').length != 0) {
                    $('.exclusive_top_referral_timer').counter().on('counterStop', function () {
                        $(this).hide();
                    });
                }
                if ($('.exclusive_top_referral_click_timer').length != 0) {
                    $('.exclusive_top_referral_click_timer').counter().on('counterStop', function () {
                        $(this).hide();
                    });
                }
                $("body").click(function (e) {
                    $("#searchBox").hide();
                    $("#storeResults").hide();
                    $("#faqBox").hide();
                    $("#searchBoxStore").hide();
                    $("#searchList").hide();
                    $("#NotificationBox").hide();
                });
                $(".contdown-toggle").click(function(){
                    $(".contdown-clock").slideToggle();
                    $("#header").toggleClass("timer-show");
                });
                $('#account_number').focusout(function () {
                    toggleBICCode();
                });
                searchEvent("searchbtn");
                $("#searchinput").click(function (e) {
                    if ($("#searchinput").val() == $("#lbl_find_shop_action").val()) {
                        $("#searchinput").attr("value", "");
                        return false;
                    }
                });
                var opened = 0;
                $('a#open-link').click(function () {
                    $('#showBanner').hide();
                    if (opened == 0) {
                        opened1 = 0;
                        $('#showLinks').slideDown(500);
                        opened = 1;
                        return false;
                    } else {
                        $('#showLinks').slideUp(500);
                        opened = 0;
                        return false;
                    }
                });

                var opened1 = 0;
                $('a#open-banner').click(function () {
                    $('#showLinks').hide();
                    if (opened1 == 0) {
                        opened = 0;
                        $('#showBanner').slideDown(500);
                        opened1 = 1;
                        return false;
                    } else {
                        $('#showBanner').slideUp(500);
                        opened1 = 0;
                        return false;
                    }
                });
                $('form').each(function (index, value) { 
                    if(value.name != 'sort-shopsForm' && value.name != 'itune-form'  && value.name != 'cadeous-cards' ) {
                        token = 'ba46e6467d6360bba5da9009c54d5420a5d21c6c';
                        $(this).append('<input type="hidden" name="csrf_token" value="' + token + '"><input type="hidden" name="csrf_page" value="store">');
                    }
                });
                if ($.adblock === undefined) {
                    $.adblock = true;
                }
                $.fn.showOnAdBlock = function () {
                    if ($.adblock) {
                        this.show();
                    }
                    return this;
                };
                 $("#profile-dropdown").hide();
                $("#dropdown, #login-dropdown").click(function () {
                    $("#profile-dropdown").toggle();
                });

                // detect if browser is chrome Or fireFox
                function checkExtentionIsInstalled(brw){
                    if ($('#alertbar-install-bfr').length > 0 && $('#alertbar-install-aftr').length > 0) {

                        // console.log('Toolbar-Page-Alert');
                         // if ($('#alertbar-install-bfr').length > 0)
                           // $('#alertbar-install-bfr').hide();
                        if ($('#alertbar-install-aftr').length > 0)
                            $('#alertbar-install-aftr').hide();

                        var googleExtID = '';
                        var hasExtension = false;

                        var googleExtLinkObj = $('a[href^="https://chrome.google.com/webstore/detail"]');
                        if (typeof googleExtLinkObj != 'undefined' && googleExtLinkObj != null && googleExtLinkObj != '') {

                            var googleExtLink = $(googleExtLinkObj).attr('href');
                            var googleExtLink = googleExtLink.split('/');
                            googleExtID = googleExtLink[googleExtLink.length - 1];
                           // console.log('Extension ID :: ' + googleExtID);

                            if (googleExtID) {

                                if(brw == 'chrome'){
                                    chrome.runtime.sendMessage(googleExtID, {message: "isInstalled"},
                                            function (reply) {
                                                if (reply) {

                                                    if (reply.response) {
                                                        if (reply.response) {
                                                            hasExtension = true;

                                                        }
                                                    }
                                                }
                                                else {
                                                    hasExtension = false;

                                                }
                                               // console.log('Extension isInstalled :: ' + hasExtension);

                                                if (hasExtension) {
                                                    $('#alertbar-install-bfr').hide();
                                                    $('#alertbar-install-aftr').show();
                                                } else {
                                                    $('#alertbar-install-bfr').show();
                                                }
                                            });

                                }
                                if(brw == 'mozilla'){
                                    var mID = '9b91dd0e-12c4-4816-badd-010146b0ee8d';

                                    /*browser.runtime.sendMessage(mID, {message: "isInstalled"},
                                            function (reply) {

                                                console.log('InsideRuntime');

                                                if (reply) {

                                                    if (reply.response) {
                                                        if (reply.response) {
                                                            hasExtension = true;

                                                        }
                                                    }
                                                }
                                                else {
                                                    hasExtension = false;

                                                }
                                                console.log('Extension isInstalled :: ' + hasExtension);

                                                if (hasExtension) {
                                                    $('#alertbar-install-aftr').show();
                                                } else {
                                                    $('#alertbar-install-bfr').show();
                                                }
                                            });
*/
                                }


                            }

                        }


                    }
                }
                /**
                 ** Chrome Extension check if it is installed on not, check will only applied on toolbar page.
                 * */
                //console.log('Browser ' +  $.browser);
                 if($.browser.chrome){
                    checkExtentionIsInstalled('chrome');
                }
                /**
                 ** FireFor Extension check if it is installed on not, check will only applied on toolbar page.
                 * */
                if($.browser.mozilla){
                    checkExtentionIsInstalled('mozilla');
                }


            });
            function getCadeausResults(value) {
                if (value != '') {
                    $.ajax({
                        url: '/ajax/cadeaus_results.php',
                        data: "cadeaus=" + value,
                        type: 'POST',
                        success: function (resp) {
                            if (value == '') {
                                $("#cad_lists").hide();
                            } else {
                                if (resp == '') {
                                    $("#cad_lists").hide();
                                } else {
                                    $("#cad_lists").html(resp);
                                    $("#cad_lists").show();
                                }
                            }
                        }
                    });
                } else {
                    $("#cad_lists").hide();
                }
            }
            
            function update_notifications(){
                 $.ajax({
                        url: '/ajax/update_notifications.php',
                        data: "status=read",
                        type: 'POST',
                        dataType: 'json',
                        success: function (result) {
                   
                            if(result.status == 'success'){
                                
                            $('.no-notifi').show();
                            $('.notifi-all-sub').hide();
                            $('.notifi-all').hide();
                            $('.notifi-no').html('0');
                            }else{
                                //nothing updated
                            }
                        }
                    });
            }
            function storeSlider(className, sWidth, minSlide, maxSlide, totalRecords) {
                var options = {
                    slideWidth: sWidth
                };
                if (totalRecords >= 5) {
                    options.maxSlides = maxSlide;
                    options.slideMargin = 5;
                    options.minSlides = minSlide;
                    options.pager = false;
                    options.infiniteLoop =  (totalRecords >= 5 ? true : false);
                }
                else if(totalRecords == 1){
                    options.slideMargin = 5;
                    options.pager = false;
                }
                else {
                    options.maxSlides = 0;
                    options.controls = false;
                    options.slideMargin = 5;
                    options.pager = false;
                    options.infiniteLoop =  (totalRecords >= 5 ? true : false);
                }

                //console.log(options)

                $(className).bxSlider(options);
            }
            function holidayDealsSlider(className) {
                $('.' + className).bxSlider({
                    auto: false,
                    autoControls: true,
                    infiniteLoop: false
                });
            }
            function confrimCashout() {
                var txt_payout_confirmation = "Bist du dir sicher, dass du eine Auszahlung beantragen willst? Wenn du auf OK klickst, ist dein Antrag definitiv. Klicke auf Abbrechen, wenn du keine Auszahlung beantragen willst.";
                txt_payout_confirmation = txt_payout_confirmation.replace('%CASHOUT_AMOUNT%', $('#cashout_amount').val());
                return confirm(txt_payout_confirmation);
            }

            var cashOutFormId = '';
            var allowCashoutSubmit = '';
            function securityCheck(obj) {
       // alert("hello"); 
       
       /*   if (obj.formId && obj.formId === "cadeaus_checkout")
          {     
              //  alert(obj.formId);
                var first_name = document.getElementById('first_name').value;
                var last_name = document.getElementById('last_name').value;
                 var postcode = document.getElementById('postcode').value;
                
                //  alert(first_name+'2nd');     
                 if (first_name == null || first_name == "" ){
              // alert(first_name); 
               //  alert(last_name);   
                      $('#errorbox').html("Bitte Vornamen angeben").show();
                return false;
                 }
                  if (last_name == null || last_name == "" ){
              //  alert(last_name);    
                      $('#errorbox').html("Bitte E-Mail-Adresse angeben").show();
                return false;
                 }
                  if (postcode == null || postcode == "" ){
                alert(postcode);    
                      $('#errorbox').html("Bitte E-Mail-Adresse angeben").show();
                return false;
                 }
                 
                   $('#errorbox').html('').hide();   
                 }*/
        if(typeof obj.isPayPalForm !== "undefined" && obj.isFBUser == 1){
                        return true;
                }
                if(obj.isRequestPage == true){
                    var txt_login_pass = "Login-Passwort eingeben";
                    $('#frgtPass').html(txt_login_pass);
                }
                if(typeof obj.confirmMsg !== "undefined"){
                    var txt_payout_confirmation = obj.confirmMsg;
                }else{
                    var txt_payout_confirmation = "Bist du dir sicher, dass du eine Auszahlung beantragen willst? Wenn du auf OK klickst, ist dein Antrag definitiv. Klicke auf Abbrechen, wenn du keine Auszahlung beantragen willst.";
                    txt_payout_confirmation = txt_payout_confirmation.replace('%CASHOUT_AMOUNT%', $('#cashout_amount').val());
                }
                if(obj.isFBUser == 0){
                    cashOutFormId = obj.formId;
                    if(allowCashoutSubmit == ''){
                        $('#cashOutAuthLink').trigger("click");
                        $('#popup-confirmTxt').html(txt_payout_confirmation);
                        return false;
                    }else{
                        return true;
                    }
                }else{
                    return confirm(txt_payout_confirmation);
                }
            }

            var allowCashoutSubmit = '';
            function checkWhatsapp(obj) {
                    if(allowCashoutSubmit == ''){
                        $('#whatsapp').trigger("click");
                        var val = "";
                        var top_txt ="Hast du deine Handynummer, deinem Profil hinzugefügt? Dann überprüfe hier, ob sie korrekt ist, damit wir dir später deinen WhatsApp-Bonus gutschreiben können.";
                        var note_txt ="Stelle sicher, dass du die Landesvorwahl vor deiner Telefonnummer hinzufügst, damit die Registrierung erfolgreich abgeschlossen werden kann.<br> <em>0049 123 1234567</em>";
                        if($('#whatsAppTxt').length)
                            $('#whatsAppTxt').html(top_txt);
                        if($('#whatsAppNoNote').length)
                            $('#whatsAppNoNote').html(note_txt);
                        if(val == '1')
                        {
                            var txt_skip='<button class="popbtn" type="button" onclick="closePopup();"><span>Abbrechen</span></button> <button class="popbtn" type="button" value="Submit" onclick="whatsapp();"><span>Abschicken</span></button>';
                            $('#popup-Skip').html(txt_skip);
                            $('.fancybox-close').hide();
                        }
                        else
                        {
                            var txt ='<button class="popbtn" type="button" value="Submit" onclick="whatsapp();"><span>Abschicken</span></button>';
                            $('#popup-Skip').html(txt);
                            $('.fancybox-close').hide();
                        }
                      return false;
                    }else{
                        return true;
                    }
            }
            function whatsappCheckPopup() {// whatsapp popup
               loadPopupWhatsapp('.various', '775', '410');
            }

            function securityCheckPopup() {// cashout authentication popup
                loadPopup('.various', '775', '410','cashoutpopup');
            }
            function passwordAuth(){ //password authentication
                var givenPass = $('#auth_pass').val();
                var selectedCaptcha = $('#captcha_register_popup_auth').val();
                var errors = '';
                if(givenPass == ''){
                    errors += "<li>Gib dein Login Passwort ein</li>";
                }
                if(selectedCaptcha == ''){
                    errors += "Um Missbrauch vorzubeugen, bitten wir dich die richtige Figur in das rechte Kästchen zu ziehen";
                }

                if(givenPass != '' && selectedCaptcha !=''){
                    var passData = '';
                    passData = $.ajax({
                        url: '/ajax/validatePassword.php',
                        data: { pass: givenPass, captcha: selectedCaptcha },
                        type: 'POST',
                        success: function (resp) {
                            return resp;
                        },
                        async: false
                    }).responseText;
                    if($(passData).text() == '1'){// pass matched
                        closePopup();
                        allowCashoutSubmit = 1;
                        $('#'+cashOutFormId).submit();
                    }
                    if($(passData).text() == '2'){//wrong password
                        errors += "Das aktuelle Passwort ist falsch";
                    }
                    if($(passData).text() == '3'){// invalid captcha
                        errors += "Die gewählte Figur ist falsch";
                    }
                }
                $('#missingData').html(errors);
            }

              function whatsapp(){ //number adding or updation
              
                var givenNumber = $('#phone_num').val();
                var errors = '';
                if ($('#numbertype').val() == 'UNKNOWN') {
                    $('#phone_num').focus();
                    return false;
                }
                if(givenNumber == ''){
                    givenNumber = '';
                    errors += "Trage zuerst deine Handynummer ein, damit wir später deinen WhatsApp-Bonus registrieren können.";
                }
                if(givenNumber != '' ){
                    var passData = '';
                    passData = $.ajax({
                        url: '/ajax/update-number.php',
                        data: { number: givenNumber },
                        type: 'POST',
                        success: function (resp) {
                            return resp;
                        },
                        async: false
                    }).responseText;
                    if($(passData).text() == '1'){//
                        closePopup();
                        $('#showthanks').show();
                        allowCashoutSubmit = 1;
                    }
                    if($(passData).text() == '2'){//
                        closePopup();
                        errors += "something went worng";
                    }
                }
                $('#data').html(errors);
            }
            // McAfee Code
            (function () {
                var sa = document.createElement('script');
                sa.type = 'text/javascript';
                sa.async = true;
                sa.src = ('https:' == document.location.protocol ? 'https://cdn' : 'http://cdn') + '.ywxi.net/js/1.js';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(sa, s);
            })();
            var PDOPTS = PDOPTS || [];
            PDOPTS['disablefloat'] = 1;
            // inject advert
            $('head').append($('<script>', {
                type: 'text/javascript',
                src: '/general.assets/js/advertisement.js'
            })
                    );
         function closeDealBar(ele){
                document.getElementById(ele).style.display = 'none';
                //tmgSetCookie(ele, 1, 8)
            }
           
            function closeCookieBar() {
                
                 
                                    
            
               var elementExists =  document.getElementById("cookiepolicy");
                if(elementExists){
                    document.getElementById('cookiepolicy').style.display = 'none';
                    tmgSetCookie("cookiepolicy", 1, 8);
                }

                    
                                        
            }

            function tmgSetCookie(a, b, c) {
                var d = new Date;
                if (c) {
                    d.setTime(d.getTime() + c * 24 * 60 * 60 * 1000);
                    var e = "; expires=" + d.toGMTString();
                } else {
                    var f = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59);
                    var e = "; expires=" + f.toGMTString();
                }
                document.cookie = a + "=" + b + e + "; path=/"
            }
            function tmgGetCookie(a) {
                var b = a + "=";
                var c = document.cookie.split(";");
                for (var d = 0; d < c.length; d++) {
                    var e = c[d];
                    while (e.charAt(0) == " ")
                        e = e.substring(1, e.length);
                    if (e.indexOf(b) == 0)
                        return e.substring(b.length, e.length)
                }
                return null
            }
            function tmgDeleteCookie(a) {
                tmgSetCookie(a, "", -1)
            }
            function tmgInitCookie() {
                if (tmgGetCookie("cookiepolicy") == null) {
                    var proto = (("https:" == document.location.protocol) ? "https://" : "http://");
                    var imgurl = 'https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16//assets/grey_bg.png';
                    
                    //t = 'Diese Website nutzt Cookies. Warum? Klicke <a href="https://www.cashbackdeals.de/static/cookies">HIER</a> für mehr Informationen.</span><span id="cookiepolicy-accept-cookies" onclick="closeCookieBar();">Schließen</span>';
                    t = 'Auf unsere Website werden Cookies verwendet, die sowohl von Cashbackkorting, als auch von Dritten gesetzt werden. Wir machen dies, um die Funktionen auf unserer Website möglich zu machen, Einblick in das Besucherverhalten zu gewinnen, Social Media-Anwendungen zu bieten, Kundenprofile zu erstellen und Ihr Anzeigenangebot zu verbessern. Indem Sie auf unsere Website weiterklicken, erklären Sie sich mit dem Setzen sämtlicher Cookies einverstanden, wie in <a href="https://www.cashbackdeals.de/static/cookies" target="_blank">unsere Cookie-Richtlinie</a> beschrieben.</span><span id="cookiepolicy-accept-cookies" onclick="closeCookieBar();">Schließen</span>';

                  //  console.log(t);
                    var a = '<div id="cookiepolicy-wrapper"><div id="cookiepolicy-txt"><span id="cookiepolicy-notice">' + t + '</div></div>';

                    var body = document.getElementsByTagName('body')[0];
                    var cssStr = "#cookiepolicy{font-family:arial,verdana,helvetica,sans-serif;font-size:12px;z-index:2147483647;background-image:url(" + imgurl + ");position:fixed;bottom:0;left:0;width:100%;margin-left:auto;margin-right:auto;}#cookiepolicy-txt span{display:inline-block}#cookiepolicy-txt {vertical-align: text-top;line-height: 16px;text-align: center;color: #fff;font-size: 12px;font-family: arial;padding: 4px 5px 5px 0;background-color: rgba(0, 0, 0, 0.3);}#cookiepolicy-accept-cookies {background-color: #fff;font-size: 12px;color: #444;font-family: arial;opacity: 1;padding: 4px 10px 4px;    cursor: pointer;display: inline-block;float: right;font-weight: bold;margin-top: 15px;}#cookiepolicy a,#cookiepolicy a:link,#cookiepolicy a:visited,#cookiepolicy a:hover{color:#fff;text-decoration:underline}#cookiepolicy-wrapper{width:100%;margin-right:auto;margin-left:auto;position:relative}#cookiepolicy-notice{width: 90%; padding:5px 0 2px;}";
                    var style = document.createElement("style");
                    style.setAttribute("type", "text/css");
                    if (style.styleSheet) {// IE
                        style.styleSheet.cssText = cssStr;
                    } else {
                        var cssText = document.createTextNode(cssStr);
                        style.appendChild(cssText);
                    }
                    var newdiv = document.createElement('div');
                    newdiv.setAttribute('id', 'cookiepolicy');
                    newdiv.innerHTML = a;
                    body.insertBefore(style, body.firstChild);
                    body.insertBefore(newdiv, body.firstChild);
                }
            }
            var readyStateCheckInterval = setInterval(function () {
                if (document.readyState === "complete") {
                    tmgInitCookie();
                    clearInterval(readyStateCheckInterval);
                }

            }, 10);

        
        </script>
        <script type="application/ld+json">
            {  "@context" : "http://schema.org",
            "@type" : "WebSite",
            "name" : "CashbackDeals.de",
            "url" : "https://www.cashbackdeals.de/"
            }
        </script>
        <script>
            function openHomeTabs(evt, tabName) {
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tabcontent");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tablinks");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(tabName).style.display = "block";
                evt.currentTarget.className += " active";
            }

            // Get the element with id="defaultOpen" and click on it
            if($('#Cashbackday').length > 0) {
                document.getElementById("defaultOpen").click();
                var stopDate = $('#counterClock').data('stopdate');

                var nextDay = moment.tz(stopDate, "Europe/Berlin");
                $('#counterClock').countdown(nextDay.toDate(), function(event) {
                    var $this = $(this).html(event.strftime(''
                            + '<div class="time CounterNum">%H</div><div class="CounterGap">:</div>'
                            + '<div class="time CounterNum">%M</div><div class="CounterGap">:</div>'
                            + '<div class="time CounterNum">%S</div>'
                    ));
                });
               /* $('#counterClock').countdown(stopDate, function (event) {
                    var $this = $(this).html(event.strftime(''
                            + '<div class="time CounterNum">%H</div><div class="CounterGap">:</div>'
                            + '<div class="time CounterNum">%M</div><div class="CounterGap">:</div>'
                            + '<div class="time CounterNum">%S</div>'
                    ));
                });*/
            }
            if($('.dblCashbackItem').length > 0) {
                var counterClockz = $('.counterClock');
                if(counterClockz.length > 0){
                    counterClockz.each(function( idx ) {
                        var stopDate = $('.clokctner-'+idx).data('stopdate');
                        var nextDay = moment.tz(stopDate, "Europe/Berlin");
                        $('.clokctner-'+idx).countdown(nextDay.toDate(), function(event) {
                            $('.clokctner-'+idx).html(event.strftime(''
                                    + '<div class="time CounterNum">%H</div><div class="CounterGap">:</div>'
                                    + '<div class="time CounterNum">%M</div><div class="CounterGap">:</div>'
                                    + '<div class="time CounterNum">%S</div>'
                            ));
                        });
                    });
                }
            }
            /* Header Messager Timer */
            
            /* Deals Timer Start */
             if($('.deal-countdown').length > 0) {
                 var dealcountdown = $('.deal-countdown');
             
                    $.each(dealcountdown, function (index, item) {
                        var counterDivID = $('#'+$(this).attr('id'));
                        var daysLeftDivId = $('#'+$(this).attr('id')+'-daysleft');
                        var timeLeftDivId = $('#'+$(this).attr('id')+'-timeleft');
                        var dealExpiryDate = $(this).attr('data-stopdate');
                        var dealExipryDay = moment.tz(dealExpiryDate, "Europe/Berlin");
                        var IncrementedExpiryDate = moment(dealExipryDay).add(1, 'days');
                        counterDivID.countdown(IncrementedExpiryDate.toDate(), function(event) {
                           daysLeftDivId.html(event.strftime('%D'));
                            timeLeftDivId.html(event.strftime('%H:%M:%S'));
                        });
                       
                    });
            }
            /* Deals Timer End */

            
            /* Voucher Code Show */
            $('[data-vcode]').click(function() {
                var vcodeID = $(this).data('vcode');
                $('[data-vcode="'+vcodeID+'"]').hide(); // hide button
                $('[data-vcode-show="'+vcodeID+'"]').show(); // show voucher code by ID
            });


            /* Change Title after 5 minutes of inactivity */
            $(function() {
                var timerVar;
                var message = "Wir vermissen dich, komm zurück 🙂";
                var original = $('title').text();
                var minutes = 5;

                if (!document.hasFocus()) {
                    timerVar = setTimeout(function () {
                        document.title = message;
                    }, minutes * 60 * 1000);
                }

                $(window).focus(function() {
                    if (original) {
                        document.title = original;
                    }
                    clearTimeout(timerVar);
                }).blur(function() {
                    var title = $('title').text();
                    if (title != message) {
                        original = title;
                    }
                    timerVar = setTimeout(function () {
                        document.title = message;
                    }, minutes * 60 * 1000);
                });
            });
            /* End Change Title */
            
        </script>
    





    <script type="text/javascript">
        function toggleShare(obj) {
            $(obj).prev().slideToggle(500);
        }
    </script>
    <script>
        /* Footer Messager Timer */
        if ($('#timerFooter').length > 0) {
            var timer;
            var compareDateFooter = new Date('');
            compareDateFooter.setDate(compareDateFooter.getDate() + parseInt(''));
            compareDateFooter.setHours(23);
            compareDateFooter.setMinutes(59);
            compareDateFooter.setSeconds(59);
            console.log(compareDateFooter);
            console.log(compareDateFooter.getDate());
            timer = setInterval(function () {
                timeBetweenDatesFooter(compareDateFooter);
            }, 1000);
            function timeBetweenDatesFooter(toDate) {
                var dateEntered = toDate;
                var now = new Date();
                var difference = dateEntered.getTime() - now.getTime();
                if (difference <= 0) {
                    // Timer done
                    clearInterval(timer);
                    $('#timerFooter').css('visibility', 'hidden');
                } else {
                    $('#timerFooter').css('visibility', 'visible');
                    var seconds = Math.floor(difference / 1000);
                    var minutes = Math.floor(seconds / 60);
                    var hours = Math.floor(minutes / 60);
                    var days = Math.floor(hours / 24);
                    hours %= 24;
                    minutes %= 60;
                    seconds %= 60;
                    $("#timerFooter #days").text(days);
                    $("#timerFooter #hours").text(hours);
                    $("#timerFooter #minutes").text(minutes);
                    $("#timerFooter #seconds").text(seconds);
                }
            }
        }
    </script>
 
 
    <script language="javascript">
        $(document).ready(function () {
            set_fb_app("https://www.cashbackdeals.de/user/fb_login.php", "354800814617179");
        });
    </script>

    <script>
        function ftrBannerClick(type, data, isLogin) {
            if(type === "Manual") {
                $.ajax({
                    url: '/ajax/footer_banner_req.php',
                    type: 'post',
                    data: {
                        type: 'Manual',
                        user_os: 'web'
                    },
                    dataType: 'json'
                });
            }

            if((type === "Store" || type === "Voucher") && data) {
                var passData = {
                    cashback: data.cashback,
                    storeName: data.storeName,
                    urlKey: data.urlKey,
                    imgUrl: data.imgUrl,
                    isCbkDay: data.isCbkDay,
                    itemId: data.itemId,
                    channel: 'FBC'
                };
                if (isLogin) {
                    loginFancyPopUP(passData);
                } else {
                    regFancyPopUP(passData);
                }
            }
        }


        function webMsgClick(loc) {
            var msgId = '';
            // var msgType = '';
            // if (msgType == "Manual") {
            $.ajax({
                url: '/ajax/webmsg_req.php',
                type: 'post',
                data: {
                    // type: 'Manual',
                    // os: 'web',
                    // section: loc
                    id: msgId
                },
                dataType: 'json',
                success: function (data) {
                    console.log(data);
                }
            });
            return true;
            // }
        }


        function saveClickRecord(type, id) {
            var url = (type === 'TOB') ? '/ajax/takeoverbanner_req.php' : '';
            if (url !== '') {
                $.ajax({
                    url: url,
                    type: 'post',
                    data: {
                        id: id,
                        os: 'web'
                    },
                    dataType: 'json'
                });
                return true;
            }
        }



        $("#headMsg a").click(function () {
            webMsgClick('header');
        });
        $("#alertMsgFoot a").click(function () {
            webMsgClick('footer');
        });
    </script>
 
<div style="display:none;"> <a class="various"  href="#inline_store_reg" id="regPop">visit</a> <a class="various"  href="#inline_store_visit" id="visitPop">register</a>
    <a class="various" id='cashOutAuthLink' href="#inline_cashout_auth" onclick="securityCheckPopup()">click</a>
    <a class="various" id='whatsapp' href="#inline_whatsapp" onclick="whatsappCheckPopup()">click</a>
    <input type="hidden" id="title_popup" value="Willst du bis zu //1 CashCoins bei //2 bekommen?" />
    <input type="hidden" id="title_popup_cbk_day" value="Du willst bis zu //1 CashCoins bei //2 erhalten?" />
    <input type="hidden" id="store_short_desc" value="Deine Bestellung bei //store_name wird nun registriert" />
    <input type="hidden" id="store_full_desc" value="Achtung:<br /> Bestelle direkt und besuche während der Bestellung <b>keine</b> anderen Websites, sonst erhalten wir keine Vergütung von //store_name und können dir auch keine CashCoins geben. <br /> Dein Ankauf wird innerhalb von 48 Stunden in deinem Konto sichtbar." />
    <input type="hidden" id="site_title" value="CashbackDeals.de" />
    <input type="hidden" id="lbl_visit_store_btn" value="Zu //1" />  
    <input type="hidden" id="go_back" value="Zurück zu " />
    <input type="hidden" id="lbl_points_label" value="Punkt(e)" />
    <input type="hidden" id="lbl_pc_check_success" value="Perfekt!" />
    <input type="hidden" id="lbl_pc_check_fail" value='<a href="/static/tech-check">Klicke hier</a>' />
    <input type="hidden" id="lbl_extra_conditions_info" value='Ja, <a href="//1" onclick="closeFB()">klicke hier</a>' />
    <input type="hidden" id="lbl_extra_conditions_empty" value="Nein" />
</div>
<!-- Advent Calender Popup -->
<div id="inline_adventCal" style="display:none;">
    <div class="popup_table">
        <a href="https://www.cashbackkorting.nl/visit/bol-com.php" id="click"><img src="" id="advent_imgurl"></a>
    </div>
</div>
<div id="inline_store_reg" style="display:none;">
    <!-- start -->
    <div class="popup">

        <div class="popup-top signup" id="reg_main_title">
            <!-- populated by js --> 
        </div>

        <div class="popup-content">
            <div class="popup-content-padding clearfix">
                <div class="popup-content-right">
                    <div id="tabs" class="tabs">
                        <nav>
                            <ul>
                                <li><a href="#section-1" class="icon-shop"><span><i class="fa fa-user" aria-hidden="true"></i>Gratis anmelden</span></a></li>
                                <li><a href="#section-2" class="icon-cup"><span><i class="fa fa-power-off" aria-hidden="true"></i>Einloggen</span></a></li>
                            </ul>
                        </nav>
                        <div class="content">
                            <section id="section-1">

                                <form action="https://www.cashbackdeals.de/user/register.php" method="post" enctype="application/x-www-form-urlencoded" name="form1" target="_self"><!-- please remove ID or rename it -->
                                    <span class="popup-field" id="first_name_v">
                                        <input type="text" class="popup-field-input text-input textfield" id="first_name" name="first_name" autocomplete="given-name"><!-- new class -->
                                        <i class="fa fa-check-circle validMsg" aria-hidden="true"></i> 
                                    </span>
                                    <span class="popup-field"id="last_name_v">
                                        <input type="text" class="popup-field-input text-input textfield" id="last_name" name="last_name" autocomplete="family-name"><!-- new class -->
                                        <i class="fa fa-check-circle validMsg" aria-hidden="true"></i>
                                    </span>
                                    <span class="popup-field" id="email_v">
                                        <input type="text" class="popup-field-input" id="email" name="email" autocomplete="email"><!-- new class -->
                                        <i class="fa fa-check-circle validMsg" aria-hidden="true"></i> 
                                    </span>
                                    <span class="popup-field" id="password_v">
                                        <input type="text" name="passtip0" id="passtip0" value="Passwort" class="popup-field-input" onfocus="showPass(document.getElementById('passwordregister'), this)"><!-- new class -->
                                        <input type="password" name="password" id="passwordregister" class="popup-field-input" style="display: none;" onblur="hidePass(this, document.getElementById('passtip0'))" autocomplete="off"><!-- new class -->
                                        <i class="fa fa-check-circle validMsg" aria-hidden="true"></i>
                                    </span>
                                    <div class="captcha-box">
                                        <div class="myCaptcha"  id="registerContainer_popup"></div>
                                         
                                            <script language="javascript">
                                                $(document).ready(function () {
                                                    $('#registerContainer_popup').sexyCaptcha('/lib/captcha.process.php?captcha_name=captcha_register_popup', 'registerContainer_popup');
                                                });
                                            </script> 
                                         </div>
                                    <span class="popup-conditions">
                                        <span id="agree_v"><input name="agree" value="1" type="checkbox" class=" checkbox" id="agree"></span>
                                        <label> Ich stimme den <a href="javascript:void(0)" onclick="termsCondition()">AGB</a> und der <a href="javascript:void(0)" onclick="Privacy()">Datenschutzerklärung</a> von CashbackDeals zu. Ich bin 18+ und gebe die Erlaubnis täglich bis zu 4 Mal E-Mails zu erhalten, welche Werbung enthalten können. Du wirst mit CashCoins für das Klicken der meisten E-Mails belohnt. </label>
                                    </span>

                                    <span class="popup-signup-button">
                                        <button class="popbtn" type="submit" value="Melde dich gratis an"><span>Melde dich gratis an</span></button>
                                    </span>
                                    <input name="submitted" type="hidden" id="submittedReg" value="1" />
                                    <input name="country" type="hidden" id="countryReg" value="select" />
                                    <input name="ReturnUrl" type="hidden" id="ReturnUrlReg" class="ReturnUrl" value="/cashback/saturn-handytarife-de.php" />
                                </form>
                                <span class="popup-facebook-button">
                                    <a data-type="login" href="#"  onclick="fb_login();">
                                        <i class="fa fa-facebook" aria-hidden="true"></i>Mit Facebook anmelden
                                    </a>
                                </span>
                                <span class="popup-google-button">
                                    <a data-type="login" href="https://accounts.google.com/o/oauth2/auth?response_type=code&redirect_uri=https%3A%2F%2Fwww.cashbackdeals.de%2Fuser%2Flogin.php&client_id=938620705190-2v8o3st9hlts94gkfpk2jauo1fhb78s0.apps.googleusercontent.com&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email&access_type=offline&approval_prompt=force">
                                        <i class="fa fa-google-plus" aria-hidden="true"></i>Mit Google+ anmelden
                                    </a>
                                </span>
                            </section>

                            <section id="section-2">

                                <form action="https://www.cashbackdeals.de/user/login.php" method="post" enctype="application/x-www-form-urlencoded" name="form2" target="_self"><!-- please remove ID or rename it -->
                                    <span class="popup-field" id="email_v2">
                                        <input type="email" class="popup-field-input" id="email2" autocomplete="email" name="email" value="E-Mail-Adresse" onfocus="hideTextTip(this, 'E-Mail-Adresse')" onblur="showTextTip(this, 'E-Mail-Adresse')" />
                                        <i class="fa fa-check-circle validMsg" aria-hidden="true"></i> 
                                    </span>
                                    <span class="popup-field" id="password_v2">
                                        <input type="text" name="passtip" id="passtip" value="Passwort" class="popup-field-input" onfocus="showPass(document.getElementById('passwordpopup'), this)" />
                                        <input type="password" name="password" id="passwordpopup" class="popup-field-input" style="display: none;" onblur="hidePass(this, document.getElementById('passtip'))" />
                                        <i class="fa fa-check-circle validMsg" aria-hidden="true"></i>
                                    </span>

                                    <span class="popup-conditions">
                                        <label class="remember" for="rememberpassLogin"><input type="checkbox" name="rememberpass" id="rememberpassLogin" style="width: 20px" value="1" /> Passwort merken</label>
                                    </span>

                                    <span class="popup-login-button"><button class="popbtn" type="submit" value="Einloggen"><span>Einloggen</span></button></span>
                                    <span class="popup-pass"><a href ="/user/forgot-password.php" > Passwort vergessen? </a> </span>
                                    <input name="submitted" type="hidden" id="submittedLoginPopup" value="1" />
                                    <input name="ReturnUrl" type="hidden" id="ReturnUrlLoginPopup" class="ReturnUrl" value="/cashback/saturn-handytarife-de.php" />
                                </form>

                                <span class="popup-facebook-button">
                                    <a data-type="login" href="#"  onclick="fb_login();">
                                        <i class="fa fa-facebook" aria-hidden="true"></i>Mit Facebook anmelden
                                    </a>
                                </span>
                                <span class="popup-google-button">
                                    <a data-type="login" href="https://accounts.google.com/o/oauth2/auth?response_type=code&redirect_uri=https%3A%2F%2Fwww.cashbackdeals.de%2Fuser%2Flogin.php&client_id=938620705190-2v8o3st9hlts94gkfpk2jauo1fhb78s0.apps.googleusercontent.com&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email&access_type=offline&approval_prompt=force">
                                        <i class="fa fa-google-plus" aria-hidden="true"></i>Mit Google+ anmelden
                                    </a>
                                </span>
                            </section>
                        </div><!-- end tab content -->
                    </div><!-- end tabs div -->
                </div><!-- end right content -->

                <div class="popup-content-left">
                    <span class="popup-advantages">
                        <strong>Fang noch heute an Geld zu verdienen!</strong>
                        <ul>
                            <li> 10 Wege, Cash zu verdienen</li> <li> 7,50 CashCoins geschenkt</li> <li> Höchstes Cashback</li> <li> 3348 Webshops</li> <li> 100% gratis</li>
                        </ul>
                    </span>
                </div>

            </div><!-- end  popup padding-->

            <span class="popup-back-nav clearfix">
                <span class="popup-back-left"></span>
                <span class="popup-back-right"></span>
            </span>

        </div><!-- end  popup content-->
    </div>
    <!-- end  popup-->
    <script src="/general.assets/js/cbpFWTabs.js"></script>
    
        <script>
                                        new CBPFWTabs(document.getElementById('tabs'));
        </script>
    
</div>
<div id="inline_store_visit" style="display:none;">
    
    <div class="popup">

        <div class="popup-top">
            <img src="" id="store_imgurl" class="popup-banner-img"><div class="heading popup-heading-txt"><!-- short description --></div>
        </div>

        <div class="popup-info clearfix">
            <span class="popup-info-left"><span>CashCoins</span> <span id="store_cashback_range"></span></span>
            <span class="popup-info-center"><span>Extra Bedingungen</span>  <span id="extra_conditions"><!-- extra info --></span></span>
            <span class="popup-info-right pc"><span>PC Check</span> <span id="pc_check_status"></span> </span>
        </div>

        <div class="popup-advice clearfix">
            <div class="popup-advice-left"><i class="fa fa-exclamation-triangle"></i></div>
            <div class="popup-advice-right alert-msg"><!-- full description --></div>
        </div>
        <div id="storeVoucherBox">
            <div id="storeVoucherCode"></div>
        </div>
        <span class="popup-button"><a id="store_visit_link" href="" target="_blank" onclick="closeFB()"><span id="store_visit_text"></span></a></span>
        <span class="popup-back"><a id="store_detail_link" href="">Zurück zu CashbackDeals.de</a></span>
        <div class="popup-deals" style="display:none;">
            <p>Gib deine Bestellung direkt auf und besuche <strong>keine</strong> anderen Webseiten während deines Ankaufs.<br /> Dein Ankauf wird innerhalb von 48 Stunden in deinem Konto sichtbar.</p>
            <div class="popup-deals-table">
                <div class="popup-deal-heading">Schaue dir weitere Cashback-Angebote an </div>
                <div id="dealsNew"></div>
            </div>    
        </div>
    </div>
</div>
<div class="bg_flat" id="confirmBrokenLink" style="display:none;">
    <div style="position: relative; top: 20px; font-size: 12px; width: 90%; text-align: justify;"> <h2>Funktioniert der Link nicht mehr?</h2><br /> Bitte überprüfe, ob der Link zum Webshop auch nicht in einem anderen Internet-Browser funktioniert. Wenn der Link auch dort nicht funkioniert, kannst du hier auf "Bestätigen" klicken und wir werden so schnell wie möglich nach der Ursache suchen.<br><br /> Klicke auf das Kreuz oben rechts, wenn der Link <br>doch funktioniert. </div>
    <div id="genStoreLink" style="display:none;"></div>
    <div style="float:left; margin-top:20px;"> <a href="javascript:;" onclick="javascript: window.location = document.getElementById('reported-link').href;" class="fancybox_btn"><span>Bestätigen</span></a> </div>
</div>
<div id="inline_account_move_SBS" style="display: none;">
    <div class="popup continue-sbs">
        <div class="popup-top head-sbs">
            <div class="heading popup-heading-txt sbsPopupReplace">Shoppe weiter mit 100% Cashback auf %SBS_PARTNER%</div>
        </div>
        <p class='sbsPopupReplace'>Du hast keine Lust mehr, E-Mails von uns zu erhalten, willst aber weiterhin mit dem höchsten Cashback in Deutschland shoppen? Shoppe weiter über unsere neue Webseite %SBS_PARTNER% und erhalte den höchsten Cashback für deine Online-Einkäufe. Klicke auf <B>JA</b> und wir erstellen dir ein neues kostenloses Mitgliedskonto. Nicht interessiert? Dann klicke auf <B>NEIN</B> und wir schließen dein Mitgliedskonto. Dein Guthaben von <B>21,690 CashCoins </B> wird gelöscht.</p>
                                    <span class="popup-button">
            <a  href="javascript:void(0);" onclick="moveAccountToSBS({sbsPartner: ''});" ><span id="">Ja, bitte</span></a>
            <a  href="javascript:void(0);" onclick="closeAccountCBK();" ><span id="">Nein, danke</span></a>
        </span>
        <p>
            <a target="_new" href="https://"><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/sbs-move-banner.gif"/></a>
        </p>
    </div>
</div>
<div id="inline_cashout_auth" style="display:none;">
    <div class="EmailPopup">
        <div class="cross"></div><br>
        <div id="popup-confirmTxt"></div>
        <div class="inputBox">
            <div id='missingData'></div>
            <p class="SmTxt" id="frgtPass">Gib dein Passwort ein</p>
            <input name="auth_pass" id="auth_pass" type="password" autocomplete="off" />
            <div class="code001">
                <div class="captcha-box captcha-box-cashout-popup">
                    <p class="SmTxt">Um Missbrauch vorzubeugen, bitten wir dich die richtige Figur in das rechte Kästchen zu ziehen</p>
                    <div class="myCaptcha"  id="registerContainer_popup_auth"></div>
                    
                        <script language="javascript">
                            $(document).ready(function () {
                                $('#registerContainer_popup_auth').sexyCaptcha('/lib/captcha.process.php?captcha_name=captcha_register_popup_auth', 'registerContainer_popup_auth');
                            });
                        </script>
                     </div>
            </div>
        </div>
        <div class="signup-form-pass SmTxt">Passwort ändern? <a href="/user/detail/account.php">Klicke hier</a></div>
        <div>
            <button class="popbtn" type="button" onclick="closePopup();"><span>Abbrechen</span></button>
            <button class="popbtn" type="button" value="Submit" onclick="passwordAuth();"><span>Versenden</span></button>
        </div>  
    </div>
</div>
<div id="inline_whatsapp" style="display:none;">
    <div class="EmailPopup">
        <div id='whatsAppTxt'></div>
        <br>
        <div id='whatsAppNoNote' style="margin-top:10px"></div>        <div class="inputBox">
            <div id='data'></div>
            <input name="phone_num" id="phone_num" type="text" autocomplete="off" value="" />
            <!-- mobile number parser fields -->
            <input name="phoneParse" id="phone" type="hidden" value="" />
            <input type="hidden" name="culture" id="culture" value="DE" />
            <input type="hidden" name="carrier" id="carrier" value="" />
            <input type="hidden" name="numbertype" id="numbertype" value="" /><br />
            <span id="invalid_phone_number" class="errorMsgField" style="display: none;">Ungültige Telefonnummer</span>
            <span id="invalid_mobile_number" class="errorMsgField" style="display: none;">Bitte aktive Handynummer angeben</span>
            <span id="valid_phone_number"><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/licheck.png" title="Valid" alt="Valid" class="validMsg" border="0"></span>
            <!-- mobile number parser fields end -->
        </div>
        <div id="popup-Skip"></div>  
    </div>
</div>
<div id="inline_tellafriends" style=" padding:50px;display:none;">
    <div id="gmail" style="display: none; position:relative;">

    </div>
    <div id="yahoo" style="display: none; position:relative;">

    </div>
    <div id="forms" style="position:relative; display: none;">
        <form method="post" action="https://www.cashbackdeals.de/user/cashboost.php" name="cashboostForm" id="cashboostForm">
            <div class="popup_table">
                <h2>Teile CashbackDeals.de mit deinen Freunden</h2>
                <br />
                <div class="popup_details">
                    <span class="popup_label">Kontakte importieren</span>
                    <span class="popup_input"><a href="https://accounts.google.com/o/oauth2/auth?client_id=938620705190-2v8o3st9hlts94gkfpk2jauo1fhb78s0.apps.googleusercontent.com&redirect_uri=https://www.cashbackdeals.de/import_contacts/google/&scope=https://www.google.com/m8/feeds/&response_type=code" target="_blank" title="GMAIL"><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/gmail-icon.png" alt="GMAIL" /></a> <a href="https://www.cashbackdeals.de/import_contacts/yahoo/getreqtok.php" target="_blank" title="Yahoo!"><img src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/yahoo-icon.png" alt="Yahoo!" /></a></span>
                </div>
                <div class="popup_details">
                    <span class="popup_label">E-Mail-Adresse Freund</span>
                    <span class="popup_input"><label for="friend_email"></label>
                        <input type="text" name="friend_email" class="blurIn" id="friend_email" style="width:100%; height:20px; font-size: 10px;" /></span>
                    <span class=""><div class="subject-tip-box">Persönliche Nachrichten erzielen eine bessere Wirkung<img class="arrow-down" src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/referral_down.gif" alt="Referral" /> </div></span>
                </div>
                <div class="popup_details">
                    <span class="popup_label">Betreff</span>
                    <span class="popup_input"><label for="subject"></label>
                        <input type="text" name="subject" id="subject" value="zusammen Geld verdienen?" style="width:100%; height:20px;" /></span>
                </div>
                <div class="popup_details">
                    <span class="popup_label"><div class="message-tip-box">Diesen Text kannst du selbst ändern<img class="arrow-side" src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/referral_right.gif" alt="Referral" /></div></span>
                    <span class="popup_input"><label for="message"></label>
                        <textarea name="message" id="message" cols="45" rows="8" style="width: 100%;">Hi, ich nutze CashbackDeals.de seit Kurzem und möchte diese tolle und einfache Art Geld zu verdienen gerne mit dir teilen. Melde dich an und du erhältst sofort 7,50 CashCoins Willkommens-Bonus. Viel Erfolg!</textarea></span>
                </div>
                <div class="popup_details">
                    <span class="popup_label">&nbsp;</span>
                    <span class="popup_input">
                        <input type="image"  src="https://static.orangebuddies.nl/templates/www.cashbackdeals.de/march16/assets/send-btn.png" class="popup-send-btn" name="send" id="send" />
                        <input type="hidden" name="action" id="action" value="referral" />
                    </span>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" >
    var x = ['Vorname',
        'Nachname',
        'E-Mail-Adresse',
        'Passwort',
        'E-Mail-Adresse',
        'Passwort'
    ];
    $(document).ready(function () {
        validatePopup(x);
    });

</script>
</body>
</html>
